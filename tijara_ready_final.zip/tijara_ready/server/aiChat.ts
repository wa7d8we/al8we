import { invokeLLM } from "./_core/llm";
import { getRegulations, logAiChatMessage } from "./db";

function buildRegulationsContext(regulations: Awaited<ReturnType<typeof getRegulations>>) {
  if (regulations.length === 0) {
    return "لا توجد لوائح منشورة حاليًا في النظام.";
  }
  return regulations
    .map((law, index) => {
      const clauses = (law.clauses as string[]).map((clause, i) => `   ${i + 1}. ${clause}`).join("\n");
      return `${index + 1}) [${law.code}] ${law.title} — القسم: ${law.category} (الإصدار ${law.version})\n   الملخص: ${law.summary}\n${clauses}`;
    })
    .join("\n\n");
}

/**
 * Answers a visitor's question about trade regulations using only the
 * regulations actually published in this portal — never general/outside
 * knowledge — so the assistant can't invent rules that don't exist here.
 */
export async function answerVisitorQuestion(question: string, visitorKey: string) {
  const regulations = await getRegulations(false);
  const context = buildRegulationsContext(regulations);

  const systemPrompt = [
    "أنت المساعد الرسمي لبوابة وزارة التجارة. مهمتك الوحيدة هي الإجابة على أسئلة الزوار حول القوانين واللوائح المنشورة في هذه البوابة فقط.",
    "القواعد الصارمة:",
    "- استند حصرًا إلى نص اللوائح المرفق أدناه. لا تخترع مواد أو أرقامًا أو أحكامًا غير موجودة فيه.",
    "- إن لم يكن السؤال متعلقًا باللوائح المذكورة أو لم تجد إجابة كافية في النص، وضّح ذلك بصراحة واقترح على الزائر رفع شكوى أو طلب رسمي عبر خدمات البوابة بدل التخمين.",
    "- لا تقدّم استشارات قانونية ملزمة؛ أشر إلى أن الإجابة توضيحية وأن القرار الرسمي يعود لوزارة التجارة.",
    "- أجب بالعربية الفصحى المبسطة، بإيجاز ووضوح (فقرة أو فقرتين كحد أقصى)، ودون تلفيق أرقام مواد.",
    "",
    "نص اللوائح المنشورة حاليًا:",
    context,
  ].join("\n");

  const result = await invokeLLM({
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: question },
    ],
    maxTokens: 500,
  });

  const answer =
    typeof result.choices[0]?.message.content === "string"
      ? result.choices[0].message.content.trim()
      : "تعذر توليد رد الآن، حاول مجددًا بعد قليل.";

  await logAiChatMessage(visitorKey, question, answer);

  return { answer };
}
