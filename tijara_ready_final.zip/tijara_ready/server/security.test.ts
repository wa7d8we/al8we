import { beforeEach, describe, expect, it } from "vitest";
import type { Request } from "express";
import { enforceRateLimit, normalizedText, resetRateLimitsForTests, visitorKeySchema } from "./security";

function requestFrom(ip: string) {
  return { headers: { "x-forwarded-for": ip }, socket: {} } as unknown as Request;
}

describe("public endpoint hardening", () => {
  beforeEach(() => resetRateLimitsForTests());

  it("blocks requests after the configured threshold", () => {
    const req = requestFrom("203.0.113.10");
    enforceRateLimit(req, "test", 2, 60_000);
    enforceRateLimit(req, "test", 2, 60_000);
    expect(() => enforceRateLimit(req, "test", 2, 60_000)).toThrow(/تجاوز/);
  });

  it("isolates rate buckets by client address", () => {
    enforceRateLimit(requestFrom("203.0.113.10"), "test", 1, 60_000);
    expect(() => enforceRateLimit(requestFrom("203.0.113.11"), "test", 1, 60_000)).not.toThrow();
  });

  it("rejects control characters and non-UUID visitor identities", () => {
    expect(normalizedText(2, 40).safeParse("اسم\u0000مخفي").success).toBe(false);
    expect(visitorKeySchema.safeParse("predictable-key").success).toBe(false);
  });
});
