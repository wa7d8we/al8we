import { TRPCError } from "@trpc/server";
import type { Request } from "express";
import { z } from "zod";

export const FACILITY_NAMES = [
  "شركة الأركان العقارية",
  "مجموعة العليا للسيارات الجديدة",
  "القادسية للمركبات المستعملة",
  "ورشة الامتياز لتعديل المركبات",
  "ورشة ماكنزي لتعديل المركبات",
] as const;

const unsafeControlCharacters = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/;

export function normalizedText(min: number, max: number) {
  return z.string().trim().min(min).max(max).refine((value) => !unsafeControlCharacters.test(value), "يحتوي النص على محارف غير مسموحة").transform((value) => value.normalize("NFKC"));
}

export const visitorKeySchema = z.string().uuid();
export const complaintReferenceSchema = z.string().trim().toUpperCase().regex(/^CMP-[A-Z0-9]{8,24}$/, "رقم الشكوى غير صالح");
export const trackingTokenSchema = z.string().trim().regex(/^[A-Za-z0-9_-]{20,64}$/, "رمز المتابعة غير صالح");
export const phoneSchema = z.string().trim().min(5).max(24).regex(/^\+?[0-9٠-٩\s-]+$/, "رقم الجوال غير صالح");
// Discord snowflake IDs are 17-20 digit numbers (the account's numeric User ID,
// not the display name/handle — copied via Discord's "Copy User ID" action).
export const discordIdSchema = z.string().trim().regex(/^\d{17,20}$/, "آيدي الديسكورد غير صالح (يجب أن يكون رقم Copy User ID المكوّن من 17-20 رقمًا)");
export const aiChatQuestionSchema = z.string().trim().min(2, "اكتب سؤالك أولًا").max(600, "السؤال طويل جدًا، اختصره لأقل من 600 حرف").refine((value) => !unsafeControlCharacters.test(value), "يحتوي النص على محارف غير مسموحة").transform((value) => value.normalize("NFKC"));
export const evidenceUrlSchema = z.union([z.literal(""), z.string().trim().url().max(500).refine((value) => {
  try {
    const host = new URL(value).hostname.toLowerCase();
    return host === "gofile.io" || host.endsWith(".gofile.io");
  } catch {
    return false;
  }
}, "يجب أن يكون رابط الدليل من gofile.io")]);

export function clientAddress(req: Request) {
  const forwarded = req.headers["x-forwarded-for"];
  const firstForwarded = (Array.isArray(forwarded) ? forwarded[0] : forwarded)?.split(",")[0]?.trim();
  return firstForwarded || req.socket?.remoteAddress || "unknown";
}

type Bucket = { count: number; resetAt: number };
const buckets = new Map<string, Bucket>();
let operations = 0;

export function enforceRateLimit(req: Request, scope: string, limit: number, windowMs: number) {
  const now = Date.now();
  const key = `${scope}:${clientAddress(req)}`;
  const current = buckets.get(key);
  if (!current || current.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
  } else {
    current.count += 1;
    if (current.count > limit) {
      throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "تم تجاوز عدد المحاولات المسموح. حاول لاحقًا." });
    }
  }

  operations += 1;
  if (operations % 250 === 0) {
    buckets.forEach((bucket, bucketKey) => {
      if (bucket.resetAt <= now) buckets.delete(bucketKey);
    });
  }
}

export function resetRateLimitsForTests() {
  buckets.clear();
  operations = 0;
}
