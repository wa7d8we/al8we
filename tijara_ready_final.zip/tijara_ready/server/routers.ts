import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { acceptComplaint, addOwnerComplaintMessage, addReporterComplaintMessage, claimVisitorAccess, closeComplaint, createAuctionRequest, createComplaint, decideAuctionRequest, getAuctionRequests, getComplaintMessages, getComplaintsForAdmin, getLoginEvents, getRecentVisitors, getRegulations, getRentPayments, getReporterComplaint, getRoleAuditLogs, getUsersForAdmin, issueVisitorAccessCode, registerVisitor, saveRegulation, setRentPaymentStatus, updateUserRole, updateUserDisplayName } from "./db";
import { answerVisitorQuestion } from "./aiChat";
import { z } from "zod";
import { aiChatQuestionSchema, complaintReferenceSchema, discordIdSchema, enforceRateLimit, evidenceUrlSchema, FACILITY_NAMES, normalizedText, phoneSchema, trackingTokenSchema, visitorKeySchema } from "./security";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    updateName: protectedProcedure
      .input(z.object({ name: normalizedText(2, 120) }))
      .mutation(({ input, ctx }) => updateUserDisplayName(ctx.user.id, input.name)),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  visitors: router({
    register: publicProcedure
      .input(z.object({ name: normalizedText(2, 120), visitorKey: visitorKeySchema }))
      .mutation(({ input, ctx }) => {
        enforceRateLimit(ctx.req, "visitor-register", 20, 60 * 60 * 1000);
        return registerVisitor(input.name, input.visitorKey);
      }),
    recent: adminProcedure.query(() => getRecentVisitors()),
    issueAccess: adminProcedure
      .input(z.object({ visitorId: z.number().int().positive(), role: z.enum(["visitor", "owner", "manager", "staff"]), facilityId: z.enum(["f1", "f2", "f3", "f4", "f5"]) }))
      .mutation(({ input, ctx }) => issueVisitorAccessCode(input.visitorId, input.role, input.facilityId, ctx.user.id)),
    claimAccess: protectedProcedure
      .input(z.object({ claimCode: z.string().trim().regex(/^[A-Za-z0-9_-]{16}$/, "رمز التفعيل غير صالح") }))
      .mutation(({ input, ctx }) => claimVisitorAccess(ctx.user.id, input.claimCode)),
  }),

  admin: router({
    users: adminProcedure.query(() => getUsersForAdmin()),
    updateRole: adminProcedure
      .input(z.object({ id: z.number().int().positive(), role: z.enum(["visitor", "owner", "manager", "staff"]), facilityId: z.enum(["f1", "f2", "f3", "f4", "f5"]) }))
      .mutation(({ input, ctx }) => updateUserRole(input.id, input.role, input.facilityId, { id: ctx.user.id, name: ctx.user.name })),
    roleAudit: adminProcedure.query(() => getRoleAuditLogs()),
    loginEvents: adminProcedure.query(() => getLoginEvents()),
    complaints: adminProcedure.query(() => getComplaintsForAdmin()),
    messages: adminProcedure.input(z.object({ complaintId: z.number().int().positive() })).query(({ input }) => getComplaintMessages(input.complaintId)),
    acceptComplaint: adminProcedure.input(z.object({ complaintId: z.number().int().positive() })).mutation(({ input }) => acceptComplaint(input.complaintId)),
    closeComplaint: adminProcedure.input(z.object({ complaintId: z.number().int().positive() })).mutation(({ input }) => closeComplaint(input.complaintId)),
    sendMessage: adminProcedure.input(z.object({ complaintId: z.number().int().positive(), body: z.string().trim().min(1).max(4000) })).mutation(({ input }) => addOwnerComplaintMessage(input.complaintId, input.body)),
  }),

  publicComplaints: router({
    create: publicProcedure.input(z.object({ facility: z.enum(FACILITY_NAMES), reporterName: normalizedText(2, 120), phone: phoneSchema, workerName: z.union([z.literal(""), normalizedText(2, 120)]).optional(), discordUserId: discordIdSchema, evidenceUrl: evidenceUrlSchema.optional(), body: normalizedText(10, 4000) })).mutation(({ input, ctx }) => {
      enforceRateLimit(ctx.req, "complaint-create", 5, 60 * 60 * 1000);
      return createComplaint(input);
    }),
    track: publicProcedure.input(z.object({ reference: complaintReferenceSchema, trackingToken: trackingTokenSchema })).query(({ input, ctx }) => {
      enforceRateLimit(ctx.req, "complaint-track", 40, 5 * 60 * 1000);
      return getReporterComplaint(input.reference, input.trackingToken);
    }),
    sendMessage: publicProcedure.input(z.object({ reference: complaintReferenceSchema, trackingToken: trackingTokenSchema, body: normalizedText(1, 4000) })).mutation(({ input, ctx }) => {
      enforceRateLimit(ctx.req, "complaint-message", 30, 5 * 60 * 1000);
      return addReporterComplaintMessage(input.reference, input.trackingToken, input.body);
    }),
  }),

  aiChat: router({
    ask: publicProcedure
      .input(z.object({ question: aiChatQuestionSchema, visitorKey: visitorKeySchema }))
      .mutation(({ input, ctx }) => {
        // Two limits: a tight per-visitor limit and a looser per-IP limit, so
        // one visitorKey can't be swapped rapidly to dodge the cap.
        enforceRateLimit(ctx.req, `ai-chat:${input.visitorKey}`, 15, 10 * 60 * 1000);
        enforceRateLimit(ctx.req, "ai-chat-ip", 40, 10 * 60 * 1000);
        return answerVisitorQuestion(input.question, input.visitorKey);
      }),
  }),

  auctions: router({
    list: protectedProcedure.query(({ ctx }) => {
      if (ctx.user.role === "admin") return getAuctionRequests();
      if (!ctx.user.facilityId || !["owner", "manager", "staff"].includes(ctx.user.role)) throw new TRPCError({ code: "FORBIDDEN", message: "لا توجد قناة منشأة مصرح بها" });
      return getAuctionRequests(ctx.user.facilityId);
    }),
    create: protectedProcedure
      .input(z.object({ facilityId: z.enum(["f1", "f2", "f3", "f4", "f5"]), requestType: normalizedText(2, 100), summary: normalizedText(3, 240), details: normalizedText(3, 4000), auctionDate: normalizedText(3, 120), organizers: z.enum(["yes", "no"]) }))
      .mutation(({ input, ctx }) => {
        if (!["admin", "owner", "manager"].includes(ctx.user.role)) throw new TRPCError({ code: "FORBIDDEN", message: "رتبتك لا تسمح بتقديم طلب مزاد" });
        if (ctx.user.role !== "admin" && ctx.user.facilityId !== input.facilityId) throw new TRPCError({ code: "FORBIDDEN", message: "لا يمكنك تقديم طلب لقناة منشأة أخرى" });
        enforceRateLimit(ctx.req, `auction-create:${ctx.user.id}`, 10, 60 * 60 * 1000);
        return createAuctionRequest({ ...input, requesterUserId: ctx.user.id });
      }),
    decide: adminProcedure
      .input(z.object({ id: z.number().int().positive(), status: z.enum(["approved", "rejected", "needs_info"]), decisionNote: normalizedText(0, 2000) }))
      .mutation(({ input, ctx }) => decideAuctionRequest(input.id, input.status, input.decisionNote, ctx.user.id)),
  }),

  regulations: router({
    list: publicProcedure.query(({ ctx }) => getRegulations(ctx.user?.role === "admin")),
    save: adminProcedure
      .input(z.object({ id: z.number().int().positive().optional(), title: normalizedText(3, 240), category: normalizedText(2, 100), summary: normalizedText(10, 4000), clauses: z.array(normalizedText(3, 1000)).min(1).max(30), version: normalizedText(1, 40), status: z.enum(["draft", "published", "archived"]), effectiveAt: z.date() }))
      .mutation(({ input, ctx }) => saveRegulation(input, ctx.user.id)),
  }),

  rents: router({
    list: protectedProcedure.input(z.object({ facilityId: z.enum(["f1", "f2", "f3", "f4", "f5"]) })).query(({ input, ctx }) => {
      const facilityId = ctx.user.role === "admin" ? input.facilityId : ctx.user.facilityId;
      if (!facilityId || !["admin", "owner", "manager", "staff"].includes(ctx.user.role)) throw new TRPCError({ code: "FORBIDDEN", message: "لا توجد قناة إيجارات مصرح بها" });
      return getRentPayments(facilityId);
    }),
    setPaid: protectedProcedure.input(z.object({ id: z.number().int().positive(), facilityId: z.enum(["f1", "f2", "f3", "f4", "f5"]), paid: z.boolean() })).mutation(({ input, ctx }) => {
      if (!["admin", "owner", "manager"].includes(ctx.user.role)) throw new TRPCError({ code: "FORBIDDEN", message: "رتبتك لا تسمح بتأكيد السداد" });
      const facilityId = ctx.user.role === "admin" ? input.facilityId : ctx.user.facilityId;
      if (!facilityId || (ctx.user.role !== "admin" && facilityId !== input.facilityId)) throw new TRPCError({ code: "FORBIDDEN", message: "لا يمكنك تعديل إيجار منشأة أخرى" });
      return setRentPaymentStatus(input.id, facilityId, input.paid, ctx.user.id);
    }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
