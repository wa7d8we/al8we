import { and, desc, eq, isNull } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { createHash, randomBytes } from "node:crypto";
import { aiChatMessages, auctionRequests, complaints, complaintMessages, InsertUser, loginEvents, regulations, rentPayments, roleAuditLogs, users, visitorRegistrations } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "avatarUrl", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function registerVisitor(name: string, visitorKey: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(visitorRegistrations).values({ name: name.trim(), visitorKey: visitorKey.trim() }).onDuplicateKeyUpdate({ set: { name: name.trim(), lastSeenAt: new Date() } });
  return result;
}

export async function logLoginEvent(entry: { userId: number; name: string | null; email: string | null; loginMethod: string | null; ipAddress: string | null; userAgent: string | null }) {
  const db = await getDb();
  if (!db) return;
  await db.insert(loginEvents).values({
    userId: entry.userId,
    name: entry.name,
    email: entry.email,
    loginMethod: entry.loginMethod,
    ipAddress: entry.ipAddress,
    userAgent: entry.userAgent ? entry.userAgent.slice(0, 300) : null,
  });
}

export async function getLoginEvents() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(loginEvents).orderBy(desc(loginEvents.createdAt)).limit(200);
}

export async function getRecentVisitors() {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: visitorRegistrations.id, name: visitorRegistrations.name, pendingRole: visitorRegistrations.pendingRole, facilityId: visitorRegistrations.facilityId, claimedUserId: visitorRegistrations.claimedUserId, approvedAt: visitorRegistrations.approvedAt, createdAt: visitorRegistrations.createdAt, lastSeenAt: visitorRegistrations.lastSeenAt }).from(visitorRegistrations).orderBy(desc(visitorRegistrations.lastSeenAt)).limit(100);
}

export async function issueVisitorAccessCode(visitorId: number, role: "visitor" | "owner" | "manager" | "staff", facilityId: string, actorUserId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة");
  const visitor = await db.select({ id: visitorRegistrations.id, claimedUserId: visitorRegistrations.claimedUserId }).from(visitorRegistrations).where(eq(visitorRegistrations.id, visitorId)).limit(1);
  if (!visitor[0]) throw new Error("اسم الزائر غير موجود");
  if (visitor[0].claimedUserId) throw new Error("هذا الزائر مرتبط بحساب بالفعل؛ عدّل رتبته من جدول المستخدمين");
  const claimCode = randomBytes(12).toString("base64url");
  const claimCodeHash = hashTrackingToken(claimCode);
  const claimCodeExpiresAt = new Date(Date.now() + 48 * 60 * 60 * 1000);
  await db.update(visitorRegistrations).set({ pendingRole: role, facilityId, claimCodeHash, claimCodeExpiresAt, approvedByUserId: actorUserId, approvedAt: new Date() }).where(eq(visitorRegistrations.id, visitorId));
  return { claimCode, expiresAt: claimCodeExpiresAt };
}

export async function claimVisitorAccess(userId: number, claimCode: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة");
  const currentUsers = await db.select({ id: users.id, name: users.name, role: users.role }).from(users).where(eq(users.id, userId)).limit(1);
  const currentUser = currentUsers[0];
  if (!currentUser) throw new Error("الحساب غير موجود");
  if (currentUser.role === "admin") throw new Error("حساب مالك النظام محمي ولا يقبل رموز تغيير الرتبة");
  const claimCodeHash = hashTrackingToken(claimCode.trim());
  const matches = await db.select().from(visitorRegistrations).where(eq(visitorRegistrations.claimCodeHash, claimCodeHash)).limit(1);
  const invitation = matches[0];
  if (!invitation || !invitation.pendingRole || !invitation.facilityId || !invitation.claimCodeExpiresAt) throw new Error("رمز التفعيل غير صحيح");
  if (invitation.claimedUserId) throw new Error("تم استخدام رمز التفعيل مسبقًا");
  if (invitation.claimCodeExpiresAt.getTime() < Date.now()) throw new Error("انتهت صلاحية رمز التفعيل");
  const approvedRole = invitation.pendingRole;
  const approvedFacilityId = invitation.facilityId;
  await db.transaction(async (tx) => {
    const claimResult = await tx.update(visitorRegistrations).set({ claimedUserId: userId, claimCodeHash: null, claimCodeExpiresAt: null }).where(and(eq(visitorRegistrations.id, invitation.id), eq(visitorRegistrations.claimCodeHash, claimCodeHash), isNull(visitorRegistrations.claimedUserId)));
    const affectedRows = Number((claimResult as unknown as [{ affectedRows?: number }])[0]?.affectedRows || 0);
    if (affectedRows !== 1) throw new Error("تم استخدام رمز التفعيل أو إلغاؤه");
    await tx.update(users).set({ role: approvedRole, facilityId: approvedFacilityId }).where(eq(users.id, userId));
    if (currentUser.role !== approvedRole) {
      await tx.insert(roleAuditLogs).values({ actorUserId: invitation.approvedByUserId || userId, actorName: "مالك النظام · رمز تفعيل", targetUserId: userId, targetName: currentUser.name || invitation.name, previousRole: currentUser.role, newRole: approvedRole });
    }
  });
  return { role: approvedRole, facilityId: approvedFacilityId };
}

export async function getUsersForAdmin() {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: users.id, name: users.name, avatarUrl: users.avatarUrl, email: users.email, loginMethod: users.loginMethod, nameChangedAt: users.nameChangedAt, role: users.role, facilityId: users.facilityId, lastSignedIn: users.lastSignedIn }).from(users).orderBy(desc(users.lastSignedIn)).limit(200);
}

export async function updateUserDisplayName(userId: number, name: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة");
  const cleanName = name.trim();
  if (cleanName.length < 2 || cleanName.length > 120) throw new Error("الاسم يجب أن يكون بين حرفين و120 حرفًا");
  const result = await db.update(users).set({ name: cleanName, nameChangedAt: new Date() }).where(and(eq(users.id, userId), isNull(users.nameChangedAt)));
  const affectedRows = Number((result as unknown as [{ affectedRows?: number }])[0]?.affectedRows || 0);
  if (affectedRows !== 1) throw new Error("لا يمكن تغيير الاسم مرة أخرى؛ التعديل مسموح لمرة واحدة فقط");
  return { updated: true, name: cleanName };
}

export async function updateUserRole(id: number, role: "visitor" | "owner" | "manager" | "staff" | "user" | "admin", facilityId: string, actor: { id: number; name: string | null }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة");
  const target = await db.select({ id: users.id, name: users.name, role: users.role, facilityId: users.facilityId }).from(users).where(eq(users.id, id)).limit(1);
  const user = target[0];
  if (!user) throw new Error("المستخدم غير موجود");
  if (user.role === "admin") throw new Error("حساب مالك النظام محمي ولا يمكن تغيير رتبته");
  if (user.role === role && user.facilityId === facilityId) return { changed: false };
  await db.transaction(async (tx) => {
    await tx.update(users).set({ role, facilityId }).where(eq(users.id, id));
    if (user.role !== role) {
      await tx.insert(roleAuditLogs).values({
        actorUserId: actor.id,
        actorName: actor.name || "مالك النظام",
        targetUserId: user.id,
        targetName: user.name || "مستخدم بلا اسم",
        previousRole: user.role,
        newRole: role,
      });
    }
  });
  return { changed: true };
}

export async function getRoleAuditLogs() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(roleAuditLogs).orderBy(desc(roleAuditLogs.createdAt)).limit(100);
}

export async function createComplaint(input: { facility: string; reporterName: string; phone: string; workerName?: string; discordUserId: string; evidenceUrl?: string; body: string }) {
  const db = await getDb();
  if (!db) return undefined;
  const reference = `CMP-${randomBytes(8).toString("hex").toUpperCase()}`;
  const trackingToken = randomBytes(18).toString("base64url");
  const trackingTokenHash = createHash("sha256").update(trackingToken).digest("hex");
  await db.insert(complaints).values({ reference, facility: input.facility, reporterName: input.reporterName, phone: input.phone, workerName: input.workerName?.trim() || null, discordUserId: input.discordUserId.trim(), evidenceUrl: input.evidenceUrl?.trim() || null, trackingTokenHash });
  const inserted = await db.select({ id: complaints.id }).from(complaints).where(eq(complaints.reference, reference)).limit(1);
  const complaintId = inserted[0]?.id;
  if (!complaintId) return undefined;
  await db.insert(complaintMessages).values({ complaintId, senderRole: "reporter", body: input.body });
  return { reference, trackingToken };
}

export async function getComplaintsForAdmin() {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: complaints.id, reference: complaints.reference, facility: complaints.facility, reporterName: complaints.reporterName, phone: complaints.phone, workerName: complaints.workerName, discordUserId: complaints.discordUserId, evidenceUrl: complaints.evidenceUrl, subject: complaints.subject, status: complaints.status, acceptedAt: complaints.acceptedAt, lastMessageAt: complaints.lastMessageAt, createdAt: complaints.createdAt }).from(complaints).orderBy(desc(complaints.lastMessageAt)).limit(100);
}

export async function getComplaintMessages(complaintId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(complaintMessages).where(eq(complaintMessages.complaintId, complaintId)).orderBy(complaintMessages.createdAt);
}

export async function addOwnerComplaintMessage(complaintId: number, body: string) {
  const db = await getDb();
  if (!db) return;
  const current = await db.select({ status: complaints.status }).from(complaints).where(eq(complaints.id, complaintId)).limit(1);
  if (!current[0] || !["accepted", "open"].includes(current[0].status)) throw new Error("يجب قبول الشكوى قبل فتح الدردشة");
  await db.insert(complaintMessages).values({ complaintId, senderRole: "owner", body: body.trim() });
  await db.update(complaints).set({ status: "open", lastMessageAt: new Date() }).where(eq(complaints.id, complaintId));
}

export async function acceptComplaint(complaintId: number) {
  const db = await getDb();
  if (!db) return;
  const current = await db.select({ status: complaints.status }).from(complaints).where(eq(complaints.id, complaintId)).limit(1);
  if (!current[0]) throw new Error("الشكوى غير موجودة");
  if (current[0].status === "closed") throw new Error("لا يمكن قبول شكوى مغلقة");
  if (current[0].status === "new") await db.update(complaints).set({ status: "accepted", acceptedAt: new Date() }).where(eq(complaints.id, complaintId));
  return { accepted: true };
}

export async function closeComplaint(complaintId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة");
  const current = await db.select({ status: complaints.status }).from(complaints).where(eq(complaints.id, complaintId)).limit(1);
  if (!current[0]) throw new Error("الشكوى غير موجودة");
  if (current[0].status === "new") throw new Error("يجب مراجعة الشكوى وقبولها قبل إغلاقها");
  if (current[0].status !== "closed") await db.update(complaints).set({ status: "closed", lastMessageAt: new Date() }).where(eq(complaints.id, complaintId));
  return { closed: true };
}

function hashTrackingToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export async function getReporterComplaint(reference: string, trackingToken: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select({ id: complaints.id, reference: complaints.reference, facility: complaints.facility, subject: complaints.subject, status: complaints.status, acceptedAt: complaints.acceptedAt, lastMessageAt: complaints.lastMessageAt, createdAt: complaints.createdAt }).from(complaints).where(and(eq(complaints.reference, reference.trim()), eq(complaints.trackingTokenHash, hashTrackingToken(trackingToken.trim())))).limit(1);
  const complaint = result[0];
  if (!complaint) return undefined;
  const messages = await getComplaintMessages(complaint.id);
  return { ...complaint, messages };
}

export async function addReporterComplaintMessage(reference: string, trackingToken: string, body: string) {
  const db = await getDb();
  if (!db) return;
  const complaint = await getReporterComplaint(reference, trackingToken);
  if (!complaint) throw new Error("بيانات المتابعة غير صحيحة");
  if (!["accepted", "open"].includes(complaint.status)) throw new Error("تُفتح الدردشة بعد قبول الشكوى");
  await db.insert(complaintMessages).values({ complaintId: complaint.id, senderRole: "reporter", body: body.trim() });
  await db.update(complaints).set({ status: "open", lastMessageAt: new Date() }).where(eq(complaints.id, complaint.id));
}

export async function createAuctionRequest(input: { facilityId: string; requesterUserId: number; requestType: string; summary: string; details: string; auctionDate: string; organizers: "yes" | "no" }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة");
  const reference = `AUC-${randomBytes(7).toString("hex").toUpperCase()}`;
  await db.insert(auctionRequests).values({ ...input, reference });
  return { reference, status: "new" as const };
}

export async function getAuctionRequests(facilityId?: string) {
  const db = await getDb();
  if (!db) return [];
  const base = db.select().from(auctionRequests);
  return facilityId ? base.where(eq(auctionRequests.facilityId, facilityId)).orderBy(desc(auctionRequests.createdAt)).limit(200) : base.orderBy(desc(auctionRequests.createdAt)).limit(200);
}

export async function decideAuctionRequest(id: number, status: "approved" | "rejected" | "needs_info", decisionNote: string, actorUserId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة");
  const current = await db.select({ id: auctionRequests.id, status: auctionRequests.status }).from(auctionRequests).where(eq(auctionRequests.id, id)).limit(1);
  if (!current[0]) throw new Error("طلب المزاد غير موجود");
  if (current[0].status === "approved" || current[0].status === "rejected") throw new Error("صدر قرار نهائي على هذا الطلب ولا يمكن تغييره");
  await db.update(auctionRequests).set({ status, decisionNote: decisionNote.trim() || null, decidedByUserId: actorUserId, decidedAt: new Date() }).where(eq(auctionRequests.id, id));
  return { decided: true, status };
}

function parseClauses(value: string) {
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string") : [];
  } catch {
    return [];
  }
}

export async function getRegulations(includeUnpublished = false) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(regulations);
  const rows = includeUnpublished
    ? await query.orderBy(desc(regulations.effectiveAt), desc(regulations.updatedAt)).limit(200)
    : await query.where(eq(regulations.status, "published")).orderBy(desc(regulations.effectiveAt), desc(regulations.updatedAt)).limit(200);
  return rows.map(({ clausesJson, ...row }) => ({ ...row, clauses: parseClauses(clausesJson) }));
}

export async function saveRegulation(input: { id?: number; title: string; category: string; summary: string; clauses: string[]; version: string; status: "draft" | "published" | "archived"; effectiveAt: Date }, actorUserId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة");
  const values = { title: input.title, category: input.category, summary: input.summary, clausesJson: JSON.stringify(input.clauses), version: input.version, status: input.status, effectiveAt: input.effectiveAt };
  if (input.id) {
    const current = await db.select({ id: regulations.id }).from(regulations).where(eq(regulations.id, input.id)).limit(1);
    if (!current[0]) throw new Error("اللائحة غير موجودة");
    await db.update(regulations).set(values).where(eq(regulations.id, input.id));
    return { id: input.id, created: false };
  }
  const code = `LAW-${randomBytes(6).toString("hex").toUpperCase()}`;
  await db.insert(regulations).values({ ...values, code, createdByUserId: actorUserId });
  const created = await db.select({ id: regulations.id }).from(regulations).where(eq(regulations.code, code)).limit(1);
  return { id: created[0]?.id, created: true };
}

export async function getRentPayments(facilityId: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(rentPayments).where(eq(rentPayments.facilityId, facilityId)).orderBy(rentPayments.weekNumber);
}

export async function logAiChatMessage(visitorKey: string, question: string, answer: string) {
  const db = await getDb();
  if (!db) return;
  await db.insert(aiChatMessages).values({ visitorKey, question, answer });
}

export async function setRentPaymentStatus(id: number, facilityId: string, paid: boolean, actorUserId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة");
  const current = await db.select({ id: rentPayments.id }).from(rentPayments).where(and(eq(rentPayments.id, id), eq(rentPayments.facilityId, facilityId))).limit(1);
  if (!current[0]) throw new Error("دفعة الإيجار غير موجودة في قناة منشأتك");
  await db.update(rentPayments).set({ paidAt: paid ? new Date() : null, confirmedByUserId: paid ? actorUserId : null }).where(and(eq(rentPayments.id, id), eq(rentPayments.facilityId, facilityId)));
  return { updated: true, paid };
}
