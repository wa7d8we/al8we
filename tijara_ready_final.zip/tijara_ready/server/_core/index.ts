import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { enforceRateLimit } from "../security";
import { assertProductionEnv } from "./env";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  assertProductionEnv();
  const app = express();
  const server = createServer(app);
  app.disable("x-powered-by");
  app.set("trust proxy", 1);
  app.use((req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()");
    res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
    if (process.env.NODE_ENV === "production") {
      // script-src intentionally omits 'unsafe-inline': the app only loads
      // module scripts via <script src>, so tightening this closes off a
      // large class of XSS payloads without breaking anything.
      res.setHeader("Content-Security-Policy", "default-src 'self'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'; object-src 'none'; img-src 'self' data: blob:; font-src 'self' https://fonts.gstatic.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; script-src 'self'; connect-src 'self'");
      res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
      res.setHeader("Cross-Origin-Resource-Policy", "same-origin");
    }
    next();
  });
  // Global per-IP ceiling as defense-in-depth on top of the per-action limits
  // already enforced inside each router (see server/security.ts). Scoped to
  // /api and the storage proxy only — applying it to static asset requests
  // too would throttle a normal page load, which fetches dozens of files.
  app.use((req, res, next) => {
    if (!req.path.startsWith("/api/") && !req.path.startsWith("/manus-storage/")) return next();
    try {
      enforceRateLimit(req, "global", 300, 5 * 60 * 1000);
      next();
    } catch {
      res.status(429).json({ error: "تم تجاوز عدد الطلبات المسموح. حاول لاحقًا." });
    }
  });
  app.use(express.json({ limit: "1mb", type: ["application/json", "application/*+json"] }));
  app.use(express.urlencoded({ limit: "256kb", extended: false }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    (req, res, next) => {
      if (req.method !== "POST") return next();
      const origin = req.headers.origin;
      if (!origin) return next();
      const proto = (req.headers["x-forwarded-proto"] as string | undefined)?.split(",")[0]?.trim() || req.protocol;
      const expectedOrigin = `${proto}://${req.get("host")}`;
      if (origin !== expectedOrigin) {
        res.status(403).json({ error: "cross-origin request rejected" });
        return;
      }
      next();
    },
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
