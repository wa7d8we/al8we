export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
};

/** Fail closed in production instead of silently starting with weak settings. */
export function assertProductionEnv() {
  if (process.env.NODE_ENV !== "production") return;

  const required: Array<[string, string]> = [
    ["DATABASE_URL", ENV.databaseUrl],
    ["JWT_SECRET", ENV.cookieSecret],
    ["VITE_APP_ID", ENV.appId],
    ["OAUTH_SERVER_URL", ENV.oAuthServerUrl],
    ["OWNER_OPEN_ID", ENV.ownerOpenId],
  ];
  const missing = required.filter(([, value]) => value.trim().length < 16).map(([name]) => name);
  if (missing.length > 0) {
    throw new Error(`Production configuration is incomplete: ${missing.join(", ")}`);
  }
  if (ENV.cookieSecret.length < 32) {
    throw new Error("JWT_SECRET must contain at least 32 characters in production");
  }
}
