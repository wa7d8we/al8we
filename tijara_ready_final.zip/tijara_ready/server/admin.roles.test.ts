import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function contextFor(role: "user" | "admin" | "manager" | "staff"): TrpcContext {
  return {
    user: {
      id: role === "admin" ? 1 : 2,
      openId: role === "admin" ? "owner-open-id" : "user-open-id",
      email: null,
      name: role === "admin" ? "مالك النظام" : "مستخدم",
      loginMethod: "manus",
      role,
      facilityId: role === "admin" ? null : "f1",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("admin role management", () => {
  it("rejects role management from a non-admin account", async () => {
    const caller = appRouter.createCaller(contextFor("user"));
    await expect(caller.admin.users()).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.updateRole({ id: 2, role: "manager", facilityId: "f1" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.acceptComplaint({ complaintId: 1 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.closeComplaint({ complaintId: 1 })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rejects creating another system-owner rank", async () => {
    const caller = appRouter.createCaller(contextFor("admin"));
    await expect(caller.admin.updateRole({ id: 2, role: "admin", facilityId: "f1" } as never)).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("blocks non-admin auction decisions, law edits, and visitor promotions", async () => {
    const caller = appRouter.createCaller(contextFor("manager"));
    await expect(caller.auctions.decide({ id: 1, status: "approved", decisionNote: "approved" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.regulations.save({ title: "Test law", category: "Test", summary: "A sufficiently long summary", clauses: ["A valid clause"], version: "1.0", status: "published", effectiveAt: new Date() })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.visitors.issueAccess({ visitorId: 1, role: "manager", facilityId: "f1" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("blocks staff submissions and cross-facility rent updates", async () => {
    const staffCaller = appRouter.createCaller(contextFor("staff"));
    await expect(staffCaller.auctions.create({ facilityId: "f1", requestType: "مزاد", summary: "وصف صالح", details: "تفاصيل صالحة", auctionDate: "غدًا", organizers: "yes" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    const managerCaller = appRouter.createCaller(contextFor("manager"));
    await expect(managerCaller.rents.setPaid({ id: 1, facilityId: "f2", paid: true })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rejects malformed public complaint tracking credentials", async () => {
    const caller = appRouter.createCaller(contextFor("user"));
    await expect(caller.publicComplaints.track({ reference: "123", trackingToken: "weak" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
