# Tijara Portal — نسخة جاهزة للاستضافة

هذه هي النسخة الموحدة والكاملة للمشروع. تم اعتمادها بدل النسختين المتعارضتين الموجودتين في الرفع الأصلي.

## التشغيل على الاستضافة

المتطلبات: Node.js 22+، pnpm 10+، MySQL 8 أو TiDB، وHTTPS.

```bash
pnpm install --frozen-lockfile
pnpm drizzle-kit migrate
pnpm check
pnpm test
pnpm build
NODE_ENV=production pnpm start
```

## متغيرات البيئة

اضبط المتغيرات الموجودة في `HOSTING.md` قبل التشغيل، خصوصًا:

- `DATABASE_URL`
- `JWT_SECRET`
- `VITE_APP_ID`
- `OAUTH_SERVER_URL`
- `VITE_OAUTH_PORTAL_URL`
- `OWNER_OPEN_ID`

لا تضع ملف `.env` داخل الحزمة أو داخل Git.

## ملاحظة

هذه النسخة تحتوي على الخدمات الموصولة فعليًا بقاعدة البيانات: المستخدمون والصلاحيات، الشكاوى، المحادثات الخاصة، تصاريح المزادات، الإيجارات، واللوائح. بعض الخدمات المعروضة في الواجهة ما زالت بحاجة إلى API مستقل قبل استخدامها كخدمات إنتاجية.
