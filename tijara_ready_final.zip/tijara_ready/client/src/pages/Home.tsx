import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  Bell,
  Building2,
  CalendarDays,
  Check,
  CheckCheck,
  CheckCircle2,
  ChevronLeft,
  ClipboardList,
  Clock3,
  FilePlus2,
  FileText,
  FileWarning,
  Gavel,
  History,
  KeyRound,
  LayoutDashboard,
  Landmark,
  LogIn,
  Menu,
  MessageSquareWarning,
  Moon,
  MoreHorizontal,
  Plus,
  RefreshCw,
  ReceiptText,
  Search,
  Send,
  Scale,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Sun,
  UserRound,
  UserCog,
  Users,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useTheme } from "@/contexts/ThemeContext";
import { startLogin } from "@/const";

type Page = "dashboard" | "complaints" | "permits" | "rent" | "regulations" | "access";
type PermitStatus = "قيد المراجعة" | "موافق عليه" | "مطلوب استكمال" | "مرفوض";
type Role = "visitor" | "owner" | "manager" | "staff";
type ManagedRole = "visitor" | "owner" | "manager" | "staff" | "user" | "admin";
type EditableRole = "visitor" | "owner" | "manager" | "staff";
type FacilityId = "f1" | "f2" | "f3" | "f4" | "f5";
type FacilityName = "شركة الأركان العقارية" | "مجموعة العليا للسيارات الجديدة" | "القادسية للمركبات المستعملة" | "ورشة الامتياز لتعديل المركبات" | "ورشة ماكنزي لتعديل المركبات";

type Facility = {
  id: FacilityId;
  name: string;
  type: string;
  channel: string;
  owner: string;
};

const roleLabels: Record<Role, string> = { visitor: "زائر", owner: "مالك", manager: "مدير", staff: "موظف" };
const managedRoleLabels: Record<ManagedRole, string> = { visitor: "زائر", owner: "مالك منشأة", manager: "مدير", staff: "موظف", user: "مستخدم", admin: "مالك النظام" };
const editableRoles: EditableRole[] = ["visitor", "staff", "manager", "owner"];
const permissionMatrix = [
  { role: "زائر", tone: "visitor", permissions: ["عرض القوانين", "رفع شكوى"] },
  { role: "موظف", tone: "staff", permissions: ["متابعة القناة", "عرض السجلات"] },
  { role: "مدير", tone: "manager", permissions: ["تقديم الطلبات", "تأكيد الإيجارات", "إدارة القناة"] },
  { role: "مالك منشأة", tone: "owner", permissions: ["كامل صلاحيات المنشأة", "اعتماد الإجراءات"] },
];
const facilities: Facility[] = [
  { id: "f1", name: "شركة الأركان العقارية", type: "عقار", channel: "قناة شركة الأركان العقارية", owner: "مشعل العتيبي" },
  { id: "f2", name: "مجموعة العليا للسيارات الجديدة", type: "معرض سيارات جديدة", channel: "قناة مجموعة العليا", owner: "محمد السكران" },
  { id: "f3", name: "القادسية للمركبات المستعملة", type: "معرض سيارات مستعملة", channel: "قناة القادسية", owner: "جعران بن دواس" },
  { id: "f4", name: "ورشة الامتياز لتعديل المركبات", type: "ورشة مركبات", channel: "قناة ورشة الامتياز", owner: "منصور السعدي" },
  { id: "f5", name: "ورشة ماكنزي لتعديل المركبات", type: "ورشة مركبات", channel: "قناة ورشة ماكنزي", owner: "فهد ماكنزي" },
];

const auctionProfiles: Record<FacilityId, { types: string[]; summaryLabel: string; summaryPlaceholder: string; detailsLabel: string; detailsPlaceholder: string }> = {
  f1: { types: ["مزاد عقاري", "بيع أصل عقاري", "تأجير عقار بالمزاد"], summaryLabel: "وصف العقار أو الوحدة", summaryPlaceholder: "مثال: مبنى تجاري أو أرض داخل المخطط", detailsLabel: "تفاصيل الموقع والشروط", detailsPlaceholder: "اكتب الموقع والمساحة وأهم شروط البيع بشكل عام" },
  f2: { types: ["بيع مركبات جديدة", "بيع مخزون معرض", "مزاد إلكتروني"], summaryLabel: "وصف المركبات", summaryPlaceholder: "مثال: مجموعة مركبات جديدة موديلات متنوعة", detailsLabel: "تفاصيل المركبات", detailsPlaceholder: "اكتب الموديلات أو الفئة والعدد التقريبي بشكل عام" },
  f3: { types: ["بيع مركبات مستعملة", "وساطة بيع", "مزاد إلكتروني"], summaryLabel: "وصف المركبات", summaryPlaceholder: "مثال: مركبات مستعملة متعددة", detailsLabel: "تفاصيل المركبات", detailsPlaceholder: "اكتب الموديلات أو اللوحات أو الحالة بشكل عام" },
  f4: { types: ["بيع قطع ومعدات", "تصفية معدات ورشة", "مزاد خدمات تعديل"], summaryLabel: "وصف المعروض", summaryPlaceholder: "مثال: كام، مكينة، قطع تعديل أو معدات ورشة", detailsLabel: "التفاصيل الفنية", detailsPlaceholder: "اكتب نوع القطع أو المعدات وحالتها بشكل عام" },
  f5: { types: ["بيع قطع ومعدات", "تصفية معدات ورشة", "مزاد خدمات تعديل"], summaryLabel: "وصف المعروض", summaryPlaceholder: "مثال: كام، مكينة، قطع تعديل أو معدات ورشة", detailsLabel: "التفاصيل الفنية", detailsPlaceholder: "اكتب نوع القطع أو المعدات وحالتها بشكل عام" },
};

type Permit = {
  sourceId?: number;
  id: string;
  title: string;
  facility: string;
  date: string;
  status: PermitStatus;
  decisionNote?: string | null;
};

type RentRecord = {
  id: number;
  week: string;
  unit: string;
  amount: string;
  due: string;
  paid: boolean;
  note: string;
};

type Regulation = {
  id: number;
  code: string;
  title: string;
  category: string;
  updated: string;
  body: string;
  clauses: string[];
  version: string;
  status: "draft" | "published" | "archived";
};

type SubmittedDocument = {
  reference: string;
  title: string;
  fields: { label: string; value: string }[];
  date: string;
};

type ComplaintAccess = {
  reference: string;
  trackingToken: string;
};

type ServiceKey = "permit" | "objection" | "weekly" | "monthly" | "closure" | "complaint" | "compensation";

type ServiceDefinition = {
  key: ServiceKey;
  title: string;
  audience: "خاص بالمستثمرين" | "خاص بالمواطن";
  description: string;
  icon: typeof Gavel;
};

const serviceDefinitions: ServiceDefinition[] = [
  { key: "permit", title: "تقديم طلبات تصاريح المزادات", audience: "خاص بالمستثمرين", description: "ابدأ طلب تصريح مزاد جديد وأرفق بياناته الأساسية.", icon: Gavel },
  { key: "objection", title: "الاعتراض على المخالفات على السجل", audience: "خاص بالمستثمرين", description: "ارفع اعتراضك على المخالفة مع توضيح الأسباب.", icon: FileWarning },
  { key: "weekly", title: "طلب مهلة سداد الإيجار الأسبوعي", audience: "خاص بالمستثمرين", description: "قدّم طلب مهلة سداد للإيجار الأسبوعي.", icon: ReceiptText },
  { key: "monthly", title: "طلب مهلة سداد الإيجار الشهري", audience: "خاص بالمستثمرين", description: "قدّم طلب مهلة سداد للإيجار الشهري.", icon: ReceiptText },
  { key: "closure", title: "طلب التماس في قرارات إغلاق المنشأة المؤقت", audience: "خاص بالمستثمرين", description: "أرسل التماسًا على قرار الإغلاق المؤقت.", icon: Scale },
  { key: "complaint", title: "رفع شكوى على منشأة تجارية", audience: "خاص بالمواطن", description: "ارفع شكوى موثقة على منشأة تجارية.", icon: MessageSquareWarning },
  { key: "compensation", title: "طلبات التعويض · القادسية", audience: "خاص بالمواطن", description: "قدّم مطالبة تعويض مرتبطة بالقادسية للمركبات المستعملة.", icon: ShieldCheck },
];

const initialRegulations: Regulation[] = [
  { id: 1, code: "LAW-AUCTION-01", title: "ضوابط طلبات تصاريح المزادات", category: "المزادات", updated: "الإصدار 1.0", body: "تنظم هذه اللائحة مسار تقديم طلب المزاد ومراجعته واعتماده داخل البوابة.", clauses: ["لا يعد إرسال الطلب تصريحًا نهائيًا.", "يجب أن تتوافق البيانات مع نشاط المنشأة."], version: "1.0", status: "published" },
];

const navItems: { id: Page; label: string; icon: typeof LayoutDashboard; adminOnly?: boolean }[] = [
  { id: "dashboard", label: "لوحة التحكم", icon: LayoutDashboard },
  { id: "complaints", label: "الشكاوى والمتابعة", icon: MessageSquareWarning },
  { id: "permits", label: "تصاريح المزادات", icon: Gavel },
  { id: "rent", label: "متابعة الإيجارات", icon: ReceiptText },
  { id: "regulations", label: "الخدمات والقوانين", icon: ClipboardList },
  { id: "access", label: "مركز الصلاحيات", icon: KeyRound, adminOnly: true },
];

function useStoredState<T>(key: string, fallback: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const saved = localStorage.getItem(key);
      return saved ? (JSON.parse(saved) as T) : fallback;
    } catch {
      return fallback;
    }
  });

  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(value));
  }, [key, value]);

  return [value, setValue] as const;
}

function MinistryMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="ministry-mark">
      <img className="saudi-ministry-logo" src="/brand/ministry-commerce.png" alt="وزارة التجارة Ministry of Commerce" />
      <div className={`mark-copy ${compact ? "compact" : ""}`}>
        <strong>وزارة التجارة</strong>
        {!compact && <small>المملكة العربية السعودية</small>}
      </div>
    </div>
  );
}

function StatusPill({ status }: { status: PermitStatus }) {
  const classes = status === "موافق عليه" ? "status-approved" : status === "مطلوب استكمال" ? "status-warning" : status === "مرفوض" ? "status-rejected" : "status-review";
  return <span className={`status-pill ${classes}`}><span className="status-dot" />{status}</span>;
}

function Dialog({ children, title, onClose }: { children: React.ReactNode; title: string; onClose: () => void }) {
  return (
    <div className="dialog-backdrop" role="presentation" onMouseDown={onClose}>
      <section className="dialog-card" role="dialog" aria-modal="true" aria-label={title} onMouseDown={(event) => event.stopPropagation()}>
        <div className="dialog-heading">
          <div>
            <p className="eyebrow">خدمات المنشآت</p>
            <h2>{title}</h2>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="إغلاق"><X size={19} /></button>
        </div>
        {children}
        <div className="dialog-rights"><img src="/brand/roshan.png" alt="شعار روشن" /><span>حقوق روشن © 2026</span></div>
      </section>
    </div>
  );
}

const documentFieldLabels: Record<string, string> = { facility: "اسم المنشأة", owner: "اسم المالك", auctionType: "نوع المزاد", summary: "وصف المعروض", details: "التفاصيل", estimatedCount: "العدد التقريبي", goodsCount: "عدد السلع", entryFees: "رسوم الدخول", vehicles: "أسماء السيارات وموديلاتها", auctionDate: "تاريخ المزاد ووقته", organizers: "توفير منظمين للمزاد", violationNumber: "رقم صادر المخالفة", decisionNumber: "رقم القرار الصادر", reason: "التسبيب", contactName: "اسم مقدم الطلب", phone: "رقم الجوال", worker: "اسم العامل", discordId: "آيدي الديسكورد (Discord)", video: "رابط الفيديو", problem: "شرح المشكلة", character: "اسم الشخصية", compensationType: "نوع التعويض", amount: "مبلغ التعويض", evidence: "الدليل", requestType: "نوع الطلب", trackingToken: "رمز المتابعة السري" };

export default function Home() {
  const { theme, toggleTheme } = useTheme();
  const [activePage, setActivePage] = useState<Page>("dashboard");
  const [menuOpen, setMenuOpen] = useState(false);
  const [dialog, setDialog] = useState<"regulation" | null>(null);
  const [serviceDialog, setServiceDialog] = useState<ServiceKey | null>(null);
  const [showWelcome, setShowWelcome] = useState(() => localStorage.getItem("tijara-welcome-seen") !== "1");
  const [profileDialog, setProfileDialog] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [selectedRegulation, setSelectedRegulation] = useState<Regulation | null>(null);
  const [profileName, setProfileName] = useStoredState("tijara-profile-name", "زائر");
  const [visitorKey] = useState(() => {
    const existing = localStorage.getItem("tijara-visitor-key");
    if (existing) return existing;
    const generated = crypto.randomUUID();
    localStorage.setItem("tijara-visitor-key", generated);
    return generated;
  });
  const [visitorSyncDone, setVisitorSyncDone] = useState(false);
  const [complaintAccess, setComplaintAccess] = useStoredState<ComplaintAccess | null>("tijara-complaint-access", null);
  const [lastNotifiedStatus, setLastNotifiedStatus] = useStoredState("tijara-complaint-notified-status", "");
  const [selectedFacilityId, setSelectedFacilityId] = useStoredState<FacilityId>("tijara-facility", "f1");
  const [query, setQuery] = useState("");
  const [regulationForm, setRegulationForm] = useState({ title: "", category: "", body: "", clauses: "", version: "1.0", status: "published" as "draft" | "published" | "archived" });
  const [editingRegulationId, setEditingRegulationId] = useState<number | null>(null);
  const [serviceDraft, setServiceDraft] = useState<Record<string, string>>({});
  const [submittedDocument, setSubmittedDocument] = useState<SubmittedDocument | null>(null);
  const [selectedPermitId, setSelectedPermitId] = useState<number | null>(null);
  const [selectedComplaintId, setSelectedComplaintId] = useState<number | null>(null);
  const [ownerMessage, setOwnerMessage] = useState("");
  const [reporterMessage, setReporterMessage] = useState("");
  const [manualReference, setManualReference] = useState("");
  const [manualTrackingToken, setManualTrackingToken] = useState("");
  const [roleSearch, setRoleSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState<"all" | ManagedRole>("all");
  const [roleDrafts, setRoleDrafts] = useState<Record<number, EditableRole>>({});
  const [facilityDrafts, setFacilityDrafts] = useState<Record<number, FacilityId>>({});
  const [visitorRoleDrafts, setVisitorRoleDrafts] = useState<Record<number, EditableRole>>({});
  const [visitorFacilityDrafts, setVisitorFacilityDrafts] = useState<Record<number, FacilityId>>({});
  const [visitorAccessCodes, setVisitorAccessCodes] = useState<Record<number, string>>({});
  const [claimCode, setClaimCode] = useState("");
  const [aiChatOpen, setAiChatOpen] = useState(false);
  const [aiChatInput, setAiChatInput] = useState("");
  const [aiChatHistory, setAiChatHistory] = useState<{ role: "user" | "assistant"; text: string }[]>([]);
  const { user: authUser, loading: authLoading } = useAuth();
  const isSystemOwner = authUser?.role === "admin";
  const requestedFacilityId = (isSystemOwner ? selectedFacilityId : authUser?.facilityId || "f1") as FacilityId;
  const registerVisitorMutation = trpc.visitors.register.useMutation();
  const updateNameMutation = trpc.auth.updateName.useMutation({ onSuccess: (result) => { setProfileName(result.name); toast.success("تم حفظ الاسم، ولا يمكن تغييره مرة أخرى"); }, onError: (error) => toast.error(error.message) });
  const recentVisitorsQuery = trpc.visitors.recent.useQuery(undefined, { enabled: isSystemOwner, retry: false, refetchInterval: isSystemOwner ? 15000 : false });
  const adminUsersQuery = trpc.admin.users.useQuery(undefined, { enabled: isSystemOwner, retry: false });
  const roleAuditQuery = trpc.admin.roleAudit.useQuery(undefined, { enabled: isSystemOwner, retry: false });
  const loginEventsQuery = trpc.admin.loginEvents.useQuery(undefined, { enabled: isSystemOwner, retry: false, refetchInterval: isSystemOwner ? 20000 : false });
  const updateRoleMutation = trpc.admin.updateRole.useMutation({ onSuccess: (result) => { adminUsersQuery.refetch(); roleAuditQuery.refetch(); toast.success(result.changed ? "تم تطبيق الرتبة وتوثيق التغيير" : "هذه الرتبة مطبقة بالفعل"); }, onError: (error) => toast.error(error.message) });
  const issueVisitorAccessMutation = trpc.visitors.issueAccess.useMutation({ onSuccess: (result, variables) => { setVisitorAccessCodes((current) => ({ ...current, [variables.visitorId]: result.claimCode })); recentVisitorsQuery.refetch(); toast.success("صدر رمز تفعيل مؤقت؛ سلّمه للمستخدم بعد تسجيل دخوله"); }, onError: (error) => toast.error(error.message) });
  const claimVisitorAccessMutation = trpc.visitors.claimAccess.useMutation({ onSuccess: () => { toast.success("تم تفعيل الرتبة والقناة بأمان"); window.setTimeout(() => window.location.reload(), 700); }, onError: (error) => toast.error(error.message) });
  const adminComplaintsQuery = trpc.admin.complaints.useQuery(undefined, { enabled: isSystemOwner, retry: false });
  const complaintMessagesInput = useMemo(() => ({ complaintId: selectedComplaintId || 0 }), [selectedComplaintId]);
  const complaintMessagesQuery = trpc.admin.messages.useQuery(complaintMessagesInput, { enabled: isSystemOwner && Boolean(selectedComplaintId), retry: false });
  const sendComplaintMessageMutation = trpc.admin.sendMessage.useMutation({ onSuccess: () => { setOwnerMessage(""); complaintMessagesQuery.refetch(); toast.success("تم إرسال الرسالة داخل المحادثة الخاصة"); } });
  const createComplaintMutation = trpc.publicComplaints.create.useMutation();
  const acceptComplaintMutation = trpc.admin.acceptComplaint.useMutation({ onSuccess: () => { adminComplaintsQuery.refetch(); complaintMessagesQuery.refetch(); toast.success("تم قبول الشكوى وفتح الدردشة للمبلغ"); }, onError: (error) => toast.error(error.message) });
  const closeComplaintMutation = trpc.admin.closeComplaint.useMutation({ onSuccess: () => { adminComplaintsQuery.refetch(); complaintMessagesQuery.refetch(); toast.success("تم إغلاق الشكوى وإيقاف المراسلة"); }, onError: (error) => toast.error(error.message) });
  const complaintTrackingInput = useMemo(() => ({ reference: complaintAccess?.reference || "", trackingToken: complaintAccess?.trackingToken || "" }), [complaintAccess]);
  const reporterComplaintQuery = trpc.publicComplaints.track.useQuery(complaintTrackingInput, { enabled: Boolean(complaintAccess?.reference && complaintAccess.trackingToken), retry: false, refetchInterval: complaintAccess ? 15000 : false });
  const reporterMessageMutation = trpc.publicComplaints.sendMessage.useMutation({ onSuccess: () => { setReporterMessage(""); reporterComplaintQuery.refetch(); toast.success("تم إرسال رسالتك داخل الشكوى"); }, onError: (error) => toast.error(error.message) });
  const aiChatMutation = trpc.aiChat.ask.useMutation({
    onSuccess: (result) => setAiChatHistory((current) => [...current, { role: "assistant", text: result.answer }]),
    onError: (error) => {
      setAiChatHistory((current) => [...current, { role: "assistant", text: "تعذر الحصول على رد الآن. حاول مجددًا بعد قليل." }]);
      toast.error(error.message);
    },
  });
  const sendAiChatMessage = () => {
    const question = aiChatInput.trim();
    if (!question || aiChatMutation.isPending) return;
    setAiChatHistory((current) => [...current, { role: "user", text: question }]);
    setAiChatInput("");
    aiChatMutation.mutate({ question, visitorKey });
  };
  const auctionRequestsQuery = trpc.auctions.list.useQuery(undefined, { enabled: Boolean(authUser), retry: false });
  const createAuctionMutation = trpc.auctions.create.useMutation({ onSuccess: (result) => { auctionRequestsQuery.refetch(); setSubmittedDocument({ reference: result.reference, title: "طلب تصريح إقامة مزاد", fields: Object.entries(serviceDraft).filter(([, value]) => value.trim()).map(([label, value]) => ({ label, value })), date: new Date().toLocaleDateString("ar-SA") }); setServiceDialog(null); toast.success("تم تسجيل طلب المزاد وإرساله للمراجعة"); }, onError: (error) => toast.error(error.message) });
  const decideAuctionMutation = trpc.auctions.decide.useMutation({ onSuccess: () => { auctionRequestsQuery.refetch(); toast.success("تم حفظ قرار طلب المزاد رسميًا"); }, onError: (error) => toast.error(error.message) });
  const regulationsQuery = trpc.regulations.list.useQuery(undefined, { retry: false });
  const saveRegulationMutation = trpc.regulations.save.useMutation({ onSuccess: () => { regulationsQuery.refetch(); setDialog(null); setEditingRegulationId(null); setRegulationForm({ title: "", category: "", body: "", clauses: "", version: "1.0", status: "published" }); toast.success("تم حفظ اللائحة في المرجع المركزي"); }, onError: (error) => toast.error(error.message) });
  const rentPaymentsQuery = trpc.rents.list.useQuery({ facilityId: requestedFacilityId }, { enabled: Boolean(authUser && (isSystemOwner || authUser.facilityId)), retry: false });
  const setRentPaidMutation = trpc.rents.setPaid.useMutation({ onSuccess: (result) => { rentPaymentsQuery.refetch(); toast.success(result.paid ? "تم تأكيد سداد الإيجار" : "تم إلغاء تأكيد السداد"); }, onError: (error) => toast.error(error.message) });

  useEffect(() => {
    if (authLoading || authUser || visitorSyncDone || !profileName.trim() || profileName === "زائر") return;
    setVisitorSyncDone(true);
    registerVisitorMutation.mutate({ name: profileName.trim(), visitorKey });
  }, [authLoading, authUser, profileName, registerVisitorMutation, visitorKey, visitorSyncDone]);

  useEffect(() => {
    const status = reporterComplaintQuery.data?.status;
    if (!status || status === "new") return;
    const notificationKey = status === "accepted" || status === "open" ? "chat-open" : status;
    if (notificationKey === lastNotifiedStatus) return;
    setLastNotifiedStatus(notificationKey);
    setNotificationsOpen(true);
    toast.success(status === "closed" ? "تم إغلاق الشكوى" : "تم قبول شكواك وفتح الدردشة الخاصة");
  }, [lastNotifiedStatus, reporterComplaintQuery.data?.status, setLastNotifiedStatus]);

  const assignedFacilityId = isSystemOwner ? selectedFacilityId : authUser?.facilityId as FacilityId | undefined;
  const selectedFacility = facilities.find((facility) => facility.id === assignedFacilityId) || facilities[0];
  const hasAssignedFacility = isSystemOwner || Boolean(authUser?.facilityId);
  const effectiveFacilityId = requestedFacilityId;
  const rentRecords: RentRecord[] = (rentPaymentsQuery.data || []).map((record) => ({ id: record.id, week: `الأسبوع ${record.weekNumber} · سبتمبر`, unit: record.unitName, amount: `${Number(record.amount).toLocaleString("en-US")} ر.س`, due: `موعد الاستحقاق: ${record.dueLabel}`, paid: Boolean(record.paidAt), note: record.paidAt ? `تم التأكيد ${new Date(record.paidAt).toLocaleDateString("ar-SA")}` : record.note }));
  const pendingRents = rentRecords.filter((record) => !record.paid).length;
  const paidRents = rentRecords.filter((record) => record.paid).length;
  const permits: Permit[] = (auctionRequestsQuery.data || []).map((request) => ({
    sourceId: request.id,
    id: request.reference,
    title: request.requestType,
    facility: facilities.find((facility) => facility.id === request.facilityId)?.name || request.facilityId,
    date: new Date(request.createdAt).toLocaleDateString("ar-SA"),
    status: request.status === "approved" ? "موافق عليه" : request.status === "needs_info" ? "مطلوب استكمال" : request.status === "rejected" ? "مرفوض" as PermitStatus : "قيد المراجعة",
    decisionNote: request.decisionNote,
  }));
  const regulations: Regulation[] = (regulationsQuery.data || []).map((item) => ({ id: item.id, code: item.code, title: item.title, category: item.category, body: item.summary, clauses: item.clauses, version: item.version, status: item.status, updated: `الإصدار ${item.version} · ${new Date(item.updatedAt).toLocaleDateString("ar-SA")}` }));
  const visibleRegulations = regulations.length ? regulations : initialRegulations;
  const selectedAuctionRequest = auctionRequestsQuery.data?.find((request) => request.id === selectedPermitId);
  const filteredPermits = useMemo(() => permits.filter((permit) => `${permit.id} ${permit.title} ${permit.facility}`.includes(query)), [permits, query]);
  const monthlyRentTotal = rentRecords.reduce((sum, record) => sum + Number(record.amount.replace(/[^0-9]/g, "")), 0).toLocaleString("ar-SA");
  const effectiveRole: Role = !authUser ? "visitor" : authUser.role === "admin" || authUser.role === "owner" ? "owner" : authUser.role === "manager" ? "manager" : authUser.role === "visitor" ? "visitor" : "staff";
  const canSubmitRequests = isSystemOwner || effectiveRole === "owner" || effectiveRole === "manager";
  const currentRoleLabel = isSystemOwner ? "مالك النظام" : roleLabels[effectiveRole];
  const filteredAdminUsers = useMemo(() => (adminUsersQuery.data || []).filter((managedUser) => {
    const matchesSearch = `${managedUser.name || ""}`.toLowerCase().includes(roleSearch.toLowerCase());
    return matchesSearch && (roleFilter === "all" || managedUser.role === roleFilter);
  }), [adminUsersQuery.data, roleFilter, roleSearch]);

  const pageInfo: Record<Page, { eyebrow: string; title: string; description: string }> = {
    dashboard: { eyebrow: effectiveRole === "visitor" ? "بوابة عامة" : "بوابة المنشآت", title: effectiveRole === "visitor" ? "مرحبًا بك في بوابة التجارة" : `مرحبًا، ${selectedFacility.name}`, description: effectiveRole === "visitor" ? "اطّلع على القوانين وارفع الشكاوى من هنا." : "تابع طلباتك واستحقاقاتك في مكان واحد." },
    complaints: { eyebrow: isSystemOwner ? "صندوق المالك" : "صوت المستفيد", title: isSystemOwner ? "مركز الشكاوى" : "شكاواي ومتابعتها", description: isSystemOwner ? "راجع البلاغات، اقبل الشكوى، ثم افتح التواصل الخاص." : "ارفع شكوى وتابع قرارها، وتفتح الدردشة بعد قبولها." },
    permits: { eyebrow: "خدمة رقمية", title: "تصاريح إقامة المزادات", description: "قدّم طلبات التصاريح وتابع حالتها حتى صدور القرار." },
    rent: { eyebrow: "متابعة مالية", title: "سجل الإيجارات الأسبوعي", description: "أكّد سداد الإيجار أسبوعيًا واطّلع على الاستحقاقات القادمة." },
    regulations: { eyebrow: "الخدمات والمرجع التشريعي", title: "الخدمات والقوانين", description: "اختر الخدمة المناسبة ثم اطّلع على أحدث الضوابط قبل التقديم." },
    access: { eyebrow: "حماية وإدارة", title: "مركز الصلاحيات", description: "حدّد رتب المستخدمين وراجع كل تغيير من سجل تدقيق محمي." },
  };

  const selectedService = serviceDefinitions.find((service) => service.key === serviceDialog);
  const isVisitor = effectiveRole === "visitor";
  const visibleNavItems = navItems.filter((item) => isVisitor ? ["dashboard", "complaints", "regulations"].includes(item.id) : hasAssignedFacility ? item.id !== "complaints" || isSystemOwner : ["dashboard", "regulations"].includes(item.id)).filter((item) => !item.adminOnly || isSystemOwner);

  const openService = (key: ServiceKey) => {
    setServiceDraft(key === "permit" ? { facility: selectedFacility.name, owner: selectedFacility.owner } : {});
    setServiceDialog(key);
  };

  const updateServiceDraft = (key: string, value: string) => setServiceDraft((current) => ({ ...current, [key]: value }));

  const submitService = async () => {
    if (!selectedService) return;
    const requiredFields = selectedService.key === "permit"
      ? ["facility", "owner", "auctionType", "summary", "details", "auctionDate", "organizers"]
      : selectedService.key === "objection"
        ? ["facility", "owner", "violationNumber", "reason"]
        : selectedService.key === "closure"
          ? ["facility", "owner", "decisionNumber", "reason"]
          : selectedService.key === "complaint"
            ? ["facility", "contactName", "phone", "discordId", "problem"]
            : selectedService.key === "compensation"
              ? ["character", "phone", "compensationType", "amount", "evidence"]
              : ["facility", "owner", "reason"];
    const missing = requiredFields.find((field) => !serviceDraft[field]?.trim());
    if (missing) {
      toast.error("يرجى تعبئة جميع الخانات المطلوبة قبل الإرسال");
      return;
    }
    let reference = `REQ-${Date.now().toString().slice(-8)}`;
    let documentFields = Object.entries(serviceDraft).filter(([, value]) => value.trim()).map(([label, value]) => ({ label, value }));
    if (selectedService.key === "permit") {
      try {
        await createAuctionMutation.mutateAsync({ facilityId: selectedFacility.id, requestType: serviceDraft.auctionType, summary: serviceDraft.summary, details: serviceDraft.details, auctionDate: serviceDraft.auctionDate, organizers: serviceDraft.organizers === "نعم" ? "yes" : "no" });
      } catch {
        return;
      }
      return;
    }
    if (selectedService.key === "complaint") {
      try {
        const created = await createComplaintMutation.mutateAsync({ facility: serviceDraft.facility as FacilityName, reporterName: serviceDraft.contactName, phone: serviceDraft.phone, workerName: serviceDraft.worker || "", discordUserId: serviceDraft.discordId.trim(), evidenceUrl: serviceDraft.video || "", body: serviceDraft.problem });
        if (!created?.reference || !created.trackingToken) throw new Error("تعذر إنشاء بيانات المتابعة");
        reference = created.reference;
        setComplaintAccess({ reference: created.reference, trackingToken: created.trackingToken });
        setLastNotifiedStatus("new");
        documentFields = [...documentFields, { label: "trackingToken", value: created.trackingToken }];
        setActivePage("complaints");
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "تعذر إرسال الشكوى، حاول مجددًا");
        return;
      }
    }
    setSubmittedDocument({ reference, title: selectedService.title, fields: documentFields, date: new Date().toLocaleDateString("ar-SA") });
    toast.success(`تم استلام ${selectedService.title} بنجاح`);
    setServiceDialog(null);
  };

  const downloadSubmittedPdf = () => {
    if (!submittedDocument) return;
    window.print();
  };

  const saveRegulation = () => {
    if (!regulationForm.title.trim() || !regulationForm.body.trim()) {
      toast.error("يرجى إدخال عنوان اللائحة ونصها");
      return;
    }
    const clauses = regulationForm.clauses.split("\n").map((clause) => clause.trim()).filter(Boolean);
    saveRegulationMutation.mutate({ id: editingRegulationId || undefined, title: regulationForm.title, category: regulationForm.category || "عام", summary: regulationForm.body, clauses: clauses.length ? clauses : [regulationForm.body], version: regulationForm.version || "1.0", status: regulationForm.status, effectiveAt: new Date() });
  };

  const openRegulationEditor = (regulation?: Regulation) => {
    setEditingRegulationId(regulation?.id || null);
    setRegulationForm(regulation ? { title: regulation.title, category: regulation.category, body: regulation.body, clauses: regulation.clauses.join("\n"), version: regulation.version, status: regulation.status } : { title: "", category: "", body: "", clauses: "", version: "1.0", status: "published" });
    setDialog("regulation");
  };

  const toggleRent = (id: number) => {
    const target = rentRecords.find((record) => record.id === id);
    if (!target || !canSubmitRequests) {
      toast.error("رتبتك لا تسمح بتعديل حالة السداد");
      return;
    }
    setRentPaidMutation.mutate({ id, facilityId: effectiveFacilityId, paid: !target.paid });
  };

  const goTo = (page: Page) => {
    setActivePage(page);
    setMenuOpen(false);
  };

  const saveProfile = () => {
    if (authUser && !authUser.nameChangedAt) {
      updateNameMutation.mutate({ name: profileName.trim() });
      return;
    }
    if (!profileName.trim()) {
      toast.error("اكتب اسمًا صالحًا للمستخدم");
      return;
    }
    if (effectiveRole === "visitor") {
      registerVisitorMutation.mutate({ name: profileName.trim(), visitorKey });
      setActivePage("dashboard");
    }
    setProfileDialog(false);
    toast.success("تم تحديث الاسم بنجاح — الرتبة لا تتغير من الملف الشخصي");
  };

  const renderPermitsTable = (limit?: number) => (
    <div className="table-wrap">
      <table>
        <thead>
          <tr><th>رقم الطلب</th><th>نوع الخدمة</th><th>المنشأة</th><th>تاريخ التقديم</th><th>الحالة</th><th /></tr>
        </thead>
        <tbody>
          {filteredPermits.slice(0, limit).map((permit) => (
            <tr key={permit.id}>
              <td><span className="permit-id">{permit.id}</span></td>
              <td className="cell-title">{permit.title}</td>
              <td>{permit.facility}</td>
              <td className="muted-cell">{permit.date}</td>
              <td><StatusPill status={permit.status} /></td>
              <td><div className="permit-decision-actions"><button className="table-action" onClick={() => setSelectedPermitId(permit.sourceId || null)} aria-label="عرض تفاصيل الطلب"><MoreHorizontal size={17} /></button>{isSystemOwner && permit.sourceId && permit.status === "قيد المراجعة" && <><button className="approve-permit" disabled={decideAuctionMutation.isPending} onClick={() => decideAuctionMutation.mutate({ id: permit.sourceId!, status: "approved", decisionNote: "تمت الموافقة بعد مراجعة البيانات" })}><CheckCircle2 size={14} /> قبول</button><button className="needs-info-permit" disabled={decideAuctionMutation.isPending} onClick={() => decideAuctionMutation.mutate({ id: permit.sourceId!, status: "needs_info", decisionNote: "يرجى استكمال بيانات الطلب" })}>استكمال</button></>}</div></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  const renderRentRows = (showAll = false) => (
    <div className="rent-list">
      {rentRecords.slice(0, showAll ? rentRecords.length : 3).map((rent, index) => (
        <article className={`rent-row ${rent.paid ? "rent-paid" : ""}`} key={rent.id}>
          <div className="rent-sequence"><span>{index + 1}</span>{index < rentRecords.length - 1 && <i />}</div>
          <div className="rent-main">
            <div className="rent-title-line"><h3>{rent.week}</h3>{rent.paid && <span className="paid-label"><Check size={13} /> مسدد</span>}</div>
            <p>{rent.unit}</p>
            <small>{rent.note}</small>
          </div>
          <div className="rent-amount"><strong>{rent.amount}</strong><span>{rent.due}</span></div>
          <button className={`payment-check ${rent.paid ? "checked" : ""}`} disabled={!canSubmitRequests || setRentPaidMutation.isPending} onClick={() => toggleRent(rent.id)} aria-pressed={rent.paid}>
            {rent.paid ? <Check size={18} strokeWidth={3} /> : <span />}
            <b>{canSubmitRequests ? rent.paid ? "تأكيد السداد" : "تأكيد الدفع" : "للعرض فقط"}</b>
          </button>
        </article>
      ))}
    </div>
  );

  const renderVisitorHome = () => (
    <>
      <section className="visitor-hero section-shell">
        <div><span className="visitor-kicker"><ShieldCheck size={14} /> دخول عام آمن</span><h2>خدمات التجارة متاحة لك بوضوح</h2><p>اطّلع على القوانين واللوائح، ارفع شكوى، أو سجّل الدخول للوصول إلى لوحة المنشأة ومركز الصلاحيات.</p><div className="visitor-actions"><button className="primary-button" onClick={() => startLogin()}><LogIn size={17} /> دخول المالك أو الموظف</button><button className="soft-button" onClick={() => openService("complaint")}><MessageSquareWarning size={17} /> رفع شكوى</button><button className="text-button" onClick={() => goTo("regulations")}><ClipboardList size={16} /> القوانين</button></div></div><div className="visitor-illustration"><Landmark size={58} /><span>بوابة<br />التجارة</span></div>
      </section>
      <section className="visitor-section"><div className="section-heading"><div><p className="eyebrow">قنوات المنشآت</p><h2>أسماء المنشآت المسجلة</h2></div><span>القنوات العامة متاحة للزائر</span></div><div className="facility-cards">{facilities.map((facility) => <article className="facility-card" key={facility.id}><div className="facility-card-icon"><Building2 size={21} /></div><div><strong>{facility.name}</strong><small>{facility.type}</small></div><button onClick={() => { setSelectedFacilityId(facility.id); toast.success(`تم فتح ${facility.channel}`); }}><ChevronLeft size={17} /></button></article>)}</div></section>
      <section className="visitor-public-grid"><article className="public-card"><span className="public-icon laws"><Scale size={20} /></span><div><p className="eyebrow">مرجع رسمي</p><h3>قوانين التجارة</h3><p>تصفح أحدث الضوابط واللوائح قبل تقديم أي طلب.</p><button onClick={() => goTo("regulations")}>استعراض القوانين <ChevronLeft size={15} /></button></div></article><article className="public-card"><span className="public-icon complaint"><MessageSquareWarning size={20} /></span><div><p className="eyebrow">صوت المستفيد</p><h3>رفع شكوى على منشأة</h3><p>قدّم شكواك مع البيانات المطلوبة وبشكل موثق.</p><button onClick={() => openService("complaint")}>ابدأ الشكوى <ChevronLeft size={15} /></button></div></article></section>
    </>
  );

  const renderComplaints = () => {
    const statusLabels = { new: "قيد المراجعة", accepted: "مقبولة · الدردشة مفتوحة", open: "تواصل نشط", closed: "مغلقة" } as const;
    if (isSystemOwner) {
      const selectedComplaint = adminComplaintsQuery.data?.find((complaint) => complaint.id === selectedComplaintId);
      const chatEnabled = selectedComplaint && ["accepted", "open"].includes(selectedComplaint.status);
      return <div className="complaints-center owner-complaints-center"><section className="complaints-command"><div><span className="complaints-command-icon"><MessageSquareWarning size={24} /></span><div><p className="eyebrow">صندوق البلاغات الرسمي</p><h2>من الاستقبال إلى الحل في مسار واحد</h2><p>راجع الشكوى أولًا، ثم اقبلها لفتح قناة تواصل خاصة وآمنة مع المبلغ.</p></div></div><div className="complaint-command-stats"><span><strong>{adminComplaintsQuery.data?.filter((item) => item.status === "new").length || 0}</strong> بانتظار القرار</span><span><strong>{adminComplaintsQuery.data?.filter((item) => ["accepted", "open"].includes(item.status)).length || 0}</strong> قنوات مفتوحة</span></div></section><section className="complaint-workspace"><aside className="section-shell complaint-master-list"><div className="section-heading"><div><p className="eyebrow">الوارد</p><h2>الشكاوى المستلمة</h2></div><span>{adminComplaintsQuery.data?.length || 0}</span></div><div className="complaint-list">{adminComplaintsQuery.data?.length ? adminComplaintsQuery.data.map((complaint) => <button key={complaint.id} className={`complaint-item ${selectedComplaintId === complaint.id ? "active" : ""}`} onClick={() => setSelectedComplaintId(complaint.id)}><span className="complaint-avatar"><MessageSquareWarning size={16} /></span><span><strong>{complaint.reporterName}</strong><small>{complaint.facility} · {complaint.reference}</small></span><b className={`complaint-status-${complaint.status}`}>{statusLabels[complaint.status]}</b></button>) : <div className="thread-empty"><CheckCheck size={27} /><h3>لا توجد شكاوى جديدة</h3></div>}</div></aside><section className="section-shell complaint-case-panel">{selectedComplaint ? <><div className="case-head"><div><p className="eyebrow">ملف الشكوى {selectedComplaint.reference}</p><h2>{selectedComplaint.reporterName}</h2><p>{selectedComplaint.facility} · تاريخ الاستلام {new Date(selectedComplaint.createdAt).toLocaleDateString("ar-SA")}</p></div><div className="case-head-actions"><span className={`case-status complaint-status-${selectedComplaint.status}`}>{statusLabels[selectedComplaint.status]}</span>{["accepted", "open"].includes(selectedComplaint.status) && <button className="close-case-button" disabled={closeComplaintMutation.isPending} onClick={() => closeComplaintMutation.mutate({ complaintId: selectedComplaint.id })}>إغلاق الشكوى</button>}</div></div><div className="complaint-case-facts"><span><b>رقم التواصل</b>{selectedComplaint.phone}</span>{selectedComplaint.discordUserId && <span><b>آيدي الديسكورد</b>{selectedComplaint.discordUserId}</span>}{selectedComplaint.workerName && <span><b>العامل المذكور</b>{selectedComplaint.workerName}</span>}{selectedComplaint.evidenceUrl && <a href={selectedComplaint.evidenceUrl} target="_blank" rel="noopener noreferrer"><b>دليل الفيديو</b>فتح الرابط المرفق</a>}</div>{selectedComplaint.status === "new" && <div className="acceptance-gate"><span><ShieldCheck size={23} /></span><div><h3>الدردشة مقفلة حتى قبول الشكوى</h3><p>راجع نص البلاغ، ثم اضغط قبول ليرسل النظام إشعارًا للمبلغ ويفتح المحادثة الخاصة.</p></div><button className="primary-button" disabled={acceptComplaintMutation.isPending} onClick={() => acceptComplaintMutation.mutate({ complaintId: selectedComplaint.id })}><CheckCircle2 size={16} /> قبول وفتح الدردشة</button></div>}<div className={`private-thread official-thread ${chatEnabled ? "thread-enabled" : "thread-locked"}`}><div className="thread-head"><div><p className="eyebrow">{chatEnabled ? "قناة تواصل مشفرة" : "المراسلات"}</p><h3>{chatEnabled ? "الدردشة الخاصة مع المبلغ" : "بانتظار قبول الشكوى"}</h3></div>{chatEnabled ? <ShieldCheck size={18} /> : <KeyRound size={18} />}</div><div className="thread-messages">{complaintMessagesQuery.data?.map((message) => <div key={message.id} className={`thread-message ${message.senderRole === "owner" ? "owner-message" : "reporter-message"}`}><small>{message.senderRole === "owner" ? "أنت · المالك" : "المبلغ"}</small><p>{message.body}</p></div>)}</div>{chatEnabled && <div className="thread-compose"><textarea value={ownerMessage} onChange={(event) => setOwnerMessage(event.target.value)} placeholder="اكتب ردًا رسميًا للمبلغ..." rows={3} /><button className="primary-button" disabled={!ownerMessage.trim() || sendComplaintMessageMutation.isPending} onClick={() => sendComplaintMessageMutation.mutate({ complaintId: selectedComplaint.id, body: ownerMessage })}><Send size={15} /> إرسال الرد</button></div>}</div></> : <div className="thread-empty case-empty"><MessageSquareWarning size={34} /><h3>اختر شكوى لعرض تفاصيلها</h3><p>ستظهر بيانات الشكوى وقرار القبول والدردشة هنا.</p></div>}</section></section></div>;
    }

    const complaint = reporterComplaintQuery.data;
    const chatEnabled = complaint && ["accepted", "open"].includes(complaint.status);
    return <div className="complaints-center reporter-center"><section className="reporter-intro section-shell"><div><span className="complaints-command-icon"><MessageSquareWarning size={24} /></span><div><p className="eyebrow">خدمة المستفيد</p><h2>ارفع شكواك وتابعها بخصوصية</h2><p>بعد الإرسال تحصل على رقم مرجعي ورمز متابعة سري. عند قبول الشكوى يصلك تنبيه وتُفتح الدردشة مع المالك.</p></div></div><button className="primary-button" onClick={() => openService("complaint")}><FilePlus2 size={16} /> رفع شكوى جديدة</button></section>{!complaintAccess && <section className="section-shell complaint-lookup"><div className="section-heading"><div><p className="eyebrow">لديك شكوى سابقة؟</p><h2>استرجاع المتابعة</h2></div><KeyRound size={19} /></div><p>أدخل الرقم المرجعي ورمز المتابعة السري الموجودين في مستند الاستلام.</p><div className="lookup-fields"><input value={manualReference} onChange={(event) => setManualReference(event.target.value)} placeholder="مثال: CMP-12345678" /><input value={manualTrackingToken} onChange={(event) => setManualTrackingToken(event.target.value)} placeholder="رمز المتابعة السري" /><button className="primary-button" onClick={() => { if (!manualReference.trim() || !manualTrackingToken.trim()) { toast.error("أدخل رقم الشكوى ورمز المتابعة"); return; } setComplaintAccess({ reference: manualReference.trim(), trackingToken: manualTrackingToken.trim() }); }}>فتح المتابعة</button></div></section>}{complaintAccess && <section className="reporter-case-grid"><div className="section-shell reporter-status-card"><div className="case-head"><div><p className="eyebrow">الشكوى {complaintAccess.reference}</p><h2>{reporterComplaintQuery.isLoading ? "جاري جلب حالة الشكوى..." : complaint ? complaint.facility : "تعذر العثور على الشكوى"}</h2></div>{complaint && <span className={`case-status complaint-status-${complaint.status}`}>{statusLabels[complaint.status]}</span>}</div>{complaint ? <><div className="complaint-progress"><div className="done"><span><Check size={14} /></span><strong>تم الاستلام</strong></div><i /><div className={complaint.status !== "new" ? "done" : "current"}><span>{complaint.status !== "new" ? <Check size={14} /> : <Clock3 size={14} />}</span><strong>قرار القبول</strong></div><i /><div className={chatEnabled ? "done" : "pending"}><span>{chatEnabled ? <Check size={14} /> : <MessageSquareWarning size={14} />}</span><strong>الدردشة الخاصة</strong></div></div>{complaint.status === "new" && <div className="waiting-notice"><Clock3 size={18} /><div><strong>شكواك قيد المراجعة</strong><p>ستظهر رسالة في زر التنبيهات أعلى الصفحة فور قبولها، وعندها ستُفتح الدردشة تلقائيًا.</p></div></div>}{chatEnabled && <div className="accepted-notice"><CheckCheck size={19} /><div><strong>تم قبول الشكوى</strong><p>تم فتح قناة التواصل الخاصة. يمكنك الآن مراسلة المالك من القسم أدناه.</p></div></div>}</> : <div className="invalid-tracking"><AlertTriangle size={21} /><p>بيانات المتابعة غير صحيحة أو أن هذه الشكوى قديمة ولا تحتوي رمز متابعة.</p><button className="soft-button" onClick={() => setComplaintAccess(null)}>إدخال بيانات أخرى</button></div>}<button className="text-button forget-complaint" onClick={() => setComplaintAccess(null)}>إزالة هذه الشكوى من الجهاز</button></div>{complaint && <div className={`section-shell private-thread reporter-thread ${chatEnabled ? "thread-enabled" : "thread-locked"}`}><div className="thread-head"><div><p className="eyebrow">محادثة الشكوى</p><h3>{chatEnabled ? "التواصل الخاص مع المالك" : "تُفتح بعد قبول الشكوى"}</h3></div>{chatEnabled ? <ShieldCheck size={18} /> : <KeyRound size={18} />}</div><div className="thread-messages">{complaint.messages.map((message) => <div key={message.id} className={`thread-message ${message.senderRole === "reporter" ? "owner-message" : "reporter-message"}`}><small>{message.senderRole === "reporter" ? "أنت" : "المالك"}</small><p>{message.body}</p></div>)}</div>{chatEnabled ? <div className="thread-compose"><textarea value={reporterMessage} onChange={(event) => setReporterMessage(event.target.value)} placeholder="اكتب رسالتك للمالك..." rows={3} /><button className="primary-button" disabled={!reporterMessage.trim() || reporterMessageMutation.isPending} onClick={() => reporterMessageMutation.mutate({ ...complaintAccess, body: reporterMessage })}><Send size={15} /> إرسال</button></div> : <div className="chat-lock"><KeyRound size={18} /><span>لا يمكن إرسال رسائل قبل قبول الشكوى.</span></div>}</div>}</section>}</div>;
  };

  const renderDashboard = () => {
    if (!hasAssignedFacility) return <section className="section-shell access-denied channel-pending"><Building2 size={34} /><h2>حسابك مسجل وبانتظار تعيين المنشأة</h2><p>لا يمكن عرض التصاريح أو الإيجارات أو القنوات الخاصة حتى يحدد مالك النظام رتبتك والمنشأة التابعة لك من مركز الصلاحيات.</p><span className="locked-role"><ShieldCheck size={14} /> حماية بيانات المنشآت مفعلة</span></section>;
    return <>
      <section className="summary-grid">
        <article className="summary-card accent-teal"><div className="summary-top"><span className="summary-label">طلبات قيد الإجراء</span><span className="summary-icon"><Gavel size={19} /></span></div><strong>{permits.filter(p => p.status === "قيد المراجعة").length + 2}</strong><p><span className="up-trend">+2</span> منذ الأسبوع الماضي</p></article>
        <article className="summary-card accent-amber"><div className="summary-top"><span className="summary-label">استحقاقات قريبة</span><span className="summary-icon"><Clock3 size={19} /></span></div><strong>{pendingRents}</strong><p>دفعات مجدولة هذا الشهر</p></article>
        <article className="summary-card accent-green"><div className="summary-top"><span className="summary-label">دفعات مؤكدة</span><span className="summary-icon"><CheckCircle2 size={19} /></span></div><strong>{paidRents}</strong><p>تمت مراجعتها وتوثيقها</p></article>
        <article className="summary-card accent-blue"><div className="summary-top"><span className="summary-label">تنبيهات جديدة</span><span className="summary-icon"><Bell size={19} /></span></div><strong>3</strong><p><span className="new-dot" /> تحتاج إلى مراجعة</p></article>
      </section>

      <section className="quick-actions section-shell">
        <div className="section-heading"><div><p className="eyebrow">وصول سريع</p><h2>إجراءات مباشرة</h2></div><span>اختر خدمة للبدء</span></div>
        <div className="action-grid">
          {canSubmitRequests && <button className="quick-action primary-action" onClick={() => openService("permit")}><span className="action-icon"><FilePlus2 size={21} /></span><span><strong>طلب تصريح مزاد</strong><small>ابدأ طلبًا جديدًا للمنشأة</small></span><ArrowLeft size={18} /></button>}
          <button className="quick-action" onClick={() => goTo("rent")}><span className="action-icon warm"><ReceiptText size={21} /></span><span><strong>تأكيد سداد الإيجار</strong><small>تحديث السجل الأسبوعي</small></span><ArrowLeft size={18} /></button>
          <button className="quick-action" onClick={() => goTo("regulations")}><span className="action-icon lavender"><ClipboardList size={21} /></span><span><strong>استعراض اللوائح</strong><small>آخر القوانين المعتمدة</small></span><ArrowLeft size={18} /></button>
        </div>
      </section>

      <section className="dashboard-grid">
        <div className="section-shell permits-preview">
          <div className="section-heading"><div><p className="eyebrow">تصاريح المزادات</p><h2>آخر الطلبات</h2></div><button className="text-button" onClick={() => goTo("permits")}>عرض الكل <ChevronLeft size={16} /></button></div>
          {renderPermitsTable(3)}
        </div>
        <aside className="section-shell alerts-panel">
          <div className="section-heading"><div><p className="eyebrow">متابعة فورية</p><h2>تنبيهات الإيجار</h2></div><span className="alert-count">3</span></div>
          <div className="alert-list">
            <article className="alert-item urgent"><span className="alert-icon"><AlertTriangle size={17} /></span><div><strong>دفعة هذا الأسبوع</strong><p>استحقاق إيجار المحل 14 خلال يومين.</p><button onClick={() => goTo("rent")}>مراجعة الدفعة</button></div></article>
            <article className="alert-item"><span className="alert-icon"><CalendarDays size={17} /></span><div><strong>تذكير تلقائي</strong><p>سيظهر إشعار الأسبوع الثالث في 15 سبتمبر.</p></div></article>
            <article className="alert-item"><span className="alert-icon"><ShieldCheck size={17} /></span><div><strong>سجل موثّق</strong><p>تم تأكيد دفعة الأسبوع الأول بنجاح.</p></div></article>
          </div>
          <button className="soft-button full" onClick={() => toast.success("تم إرسال تذكير الإيجار داخل البوابة")}>إرسال تذكير الآن</button>
        </aside>
      </section>
      {authUser?.role === "admin" && <><section className="section-shell admin-visitors"><div className="section-heading"><div><p className="eyebrow">مرئي للمالك فقط</p><h2>الزوار المسجلون</h2></div><span>{recentVisitorsQuery.data?.length || 0} اسمًا محفوظًا</span></div><div className="visitor-directory">{recentVisitorsQuery.data?.length ? recentVisitorsQuery.data.map((visitor) => <span key={visitor.id}><UserRound size={14} />{visitor.name}<small>{new Date(visitor.createdAt).toLocaleDateString("ar-SA")}</small></span>) : <p>لا توجد أسماء مسجلة حتى الآن.</p>}</div></section><section className="section-shell access-dashboard-link"><div><span className="access-link-icon"><KeyRound size={21} /></span><div><p className="eyebrow">إدارة الوصول المطورة</p><h2>مركز الصلاحيات</h2><p>غيّر الرتب بأمان وراجع سجل التدقيق في صفحة مستقلة.</p></div></div><button className="primary-button" onClick={() => goTo("access")}>فتح المركز <ArrowLeft size={16} /></button></section><section className="section-shell complaint-dashboard-link"><div><span className="access-link-icon"><MessageSquareWarning size={21} /></span><div><p className="eyebrow">صندوق الشكاوى المطور</p><h2>راجع واقبل وافتح التواصل</h2><p>انتقل إلى المركز المستقل لإدارة دورة الشكوى كاملة.</p></div></div><button className="primary-button" onClick={() => goTo("complaints")}>فتح مركز الشكاوى <ArrowLeft size={16} /></button></section></>}
    </>;
  };

  const renderAccessCenter = () => {
    if (!isSystemOwner) return <section className="section-shell access-denied"><ShieldCheck size={34} /><h2>هذه المنطقة محمية</h2><p>إدارة الرتب متاحة لمالك النظام فقط، ولا يستطيع أي مستخدم رفع رتبته بنفسه.</p></section>;
    const users = adminUsersQuery.data || [];
    const roleCounts = users.reduce<Record<string, number>>((counts, managedUser) => ({ ...counts, [managedUser.role]: (counts[managedUser.role] || 0) + 1 }), {});
    return (
      <div className="access-center">
        <section className="access-command-card">
          <div className="access-command-copy"><span className="security-orbit"><ShieldCheck size={24} /></span><div><p className="eyebrow">منطقة سيادية محمية</p><h2>أنت داخل حساب مالك النظام</h2><p>رتبتك الأساسية <strong>مالك النظام</strong> ومقفلة أمنيًا. لتغيير رتبة شخص آخر اختره من الجدول ثم طبّق الرتبة الجديدة.</p></div></div>
          <div className="security-score"><span>حالة الحماية</span><strong>100%</strong><small><i /> الصلاحيات الحساسة من الخادم فقط</small></div>
        </section>

        <section className="access-stats">
          <article><span className="access-stat-icon gold"><KeyRound size={19} /></span><div><small>حسابات مسجلة</small><strong>{users.length}</strong></div></article>
          <article><span className="access-stat-icon green"><ShieldCheck size={19} /></span><div><small>ملاك ومدراء</small><strong>{(roleCounts.admin || 0) + (roleCounts.owner || 0) + (roleCounts.manager || 0)}</strong></div></article>
          <article><span className="access-stat-icon blue"><History size={19} /></span><div><small>تغييرات موثقة</small><strong>{roleAuditQuery.data?.length || 0}</strong></div></article>
        </section>

        <section className="section-shell role-manager-card">
          <div className="role-manager-head"><div><p className="eyebrow">إدارة مركزية</p><h2>المستخدمون والرتب</h2><p>ابحث عن المستخدم، اختر رتبته الجديدة، ثم اضغط تطبيق. لا يتم أي تغيير بمجرد فتح القائمة.</p></div><div className="role-tools"><label className="role-search"><Search size={16} /><input value={roleSearch} onChange={(event) => setRoleSearch(event.target.value)} placeholder="ابحث بالاسم" /></label><select value={roleFilter} onChange={(event) => setRoleFilter(event.target.value as "all" | ManagedRole)}><option value="all">كل الرتب</option>{editableRoles.map((item) => <option key={item} value={item}>{managedRoleLabels[item]}</option>)}</select></div></div>
          <div className="role-table-wrap"><table className="role-table"><thead><tr><th>المستخدم</th><th>الرتبة الحالية</th><th>الرتبة الجديدة</th><th>قناة المنشأة</th><th>آخر دخول</th><th>الإجراء</th></tr></thead><tbody>{filteredAdminUsers.map((managedUser) => { const protectedOwner = managedUser.role === "admin"; const storedRole: EditableRole = editableRoles.includes(managedUser.role as EditableRole) ? managedUser.role as EditableRole : "staff"; const selectedRole = roleDrafts[managedUser.id] || storedRole; const storedFacility = (managedUser.facilityId || "f1") as FacilityId; const selectedUserFacility = facilityDrafts[managedUser.id] || storedFacility; return <tr key={managedUser.id}><td><div className="role-user"><span>{(managedUser.name || "م").charAt(0)}</span><div><strong>{managedUser.name || "مستخدم بلا اسم"}</strong><small>معرّف المستخدم #{managedUser.id}</small></div></div></td><td><span className={`role-chip role-${managedUser.role}`}>{managedRoleLabels[managedUser.role as ManagedRole]}</span></td><td>{protectedOwner ? <span className="locked-role"><ShieldCheck size={14} /> رتبة محمية</span> : <select value={selectedRole} onChange={(event) => setRoleDrafts((current) => ({ ...current, [managedUser.id]: event.target.value as EditableRole }))}>{editableRoles.map((item) => <option key={item} value={item}>{managedRoleLabels[item]}</option>)}</select>}</td><td>{protectedOwner ? <span className="locked-role"><Building2 size={14} /> جميع القنوات</span> : <select value={selectedUserFacility} onChange={(event) => setFacilityDrafts((current) => ({ ...current, [managedUser.id]: event.target.value as FacilityId }))}>{facilities.map((facility) => <option key={facility.id} value={facility.id}>{facility.name}</option>)}</select>}</td><td><span className="last-login">{new Date(managedUser.lastSignedIn).toLocaleDateString("ar-SA")}</span></td><td><button className="apply-role-button" disabled={protectedOwner || (selectedRole === managedUser.role && selectedUserFacility === managedUser.facilityId) || updateRoleMutation.isPending} onClick={() => updateRoleMutation.mutate({ id: managedUser.id, role: selectedRole, facilityId: selectedUserFacility })}><Check size={15} /> تطبيق</button></td></tr>; })}</tbody></table>{filteredAdminUsers.length === 0 && <div className="empty-state"><UserCog size={25} /><p>لا يوجد مستخدم مطابق للبحث.</p></div>}</div>
        </section>

        <section className="section-shell login-events-card"><div className="section-heading"><div><p className="eyebrow">مرئي لمالك النظام فقط · بالاسم والوقت</p><h2>من دخل البوابة</h2></div><span>{loginEventsQuery.data?.length || 0} عملية دخول مسجّلة</span></div><div className="login-events-table-wrap"><table className="role-table"><thead><tr><th>الاسم</th><th>طريقة الدخول</th><th>IP</th><th>الوقت</th></tr></thead><tbody>{loginEventsQuery.data?.length ? loginEventsQuery.data.map((event) => <tr key={event.id}><td><div className="role-user"><span>{(event.name || "م").charAt(0)}</span><div><strong>{event.name || "بدون اسم"}</strong><small>{event.email || `معرّف #${event.userId}`}</small></div></div></td><td>{event.loginMethod || "—"}</td><td><code>{event.ipAddress || "—"}</code></td><td><span className="last-login">{new Date(event.createdAt).toLocaleString("ar-SA")}</span></td></tr>) : <tr><td colSpan={4}><div className="empty-state"><UserRound size={22} /><p>لا توجد عمليات دخول مسجّلة بعد.</p></div></td></tr>}</tbody></table></div></section>

        <section className="access-lower-grid">
          <div className="section-shell permissions-card"><div className="section-heading"><div><p className="eyebrow">قاعدة واضحة</p><h2>ماذا تتيح كل رتبة؟</h2></div><SlidersHorizontal size={20} /></div><div className="permission-list">{permissionMatrix.map((item) => <article key={item.role}><span className={`permission-role ${item.tone}`}>{item.role}</span><div>{item.permissions.map((permission) => <small key={permission}><CheckCircle2 size={13} /> {permission}</small>)}</div></article>)}</div></div>
          <div className="section-shell audit-card"><div className="section-heading"><div><p className="eyebrow">سجل غير قابل للتعديل</p><h2>آخر تغييرات الصلاحيات</h2></div><History size={20} /></div><div className="audit-list">{roleAuditQuery.data?.length ? roleAuditQuery.data.slice(0, 8).map((entry) => <article key={entry.id}><span className="audit-line" /><div><strong>{entry.targetName}</strong><p>من {managedRoleLabels[entry.previousRole as ManagedRole]} إلى <b>{managedRoleLabels[entry.newRole as ManagedRole]}</b></p><small>{entry.actorName} · {new Date(entry.createdAt).toLocaleString("ar-SA")}</small></div></article>) : <div className="audit-empty"><History size={24} /><p>سيظهر هنا أول تغيير تقوم به.</p></div>}</div></div>
        </section>
        <section className="section-shell registered-visitors-card"><div className="role-manager-head"><div><p className="eyebrow">مرئي لمالك النظام فقط</p><h2>سجل الأسماء وتعيين الرتب</h2><p>اختر رتبة الزائر ومنشأته ثم أصدر رمزًا مؤقتًا. لا تُمنح الصلاحية إلا بعد تسجيل المستخدم ودخوله بالرمز.</p></div><button className="soft-button" onClick={() => recentVisitorsQuery.refetch()}><RefreshCw size={15} /> تحديث القائمة</button></div><div className="registered-visitors-grid access-enabled">{recentVisitorsQuery.data?.length ? recentVisitorsQuery.data.map((visitor) => { const visitorRole = visitorRoleDrafts[visitor.id] || visitor.pendingRole || "visitor"; const visitorFacility = visitorFacilityDrafts[visitor.id] || (visitor.facilityId as FacilityId) || "f1"; const issuedCode = visitorAccessCodes[visitor.id]; return <article key={visitor.id} className="visitor-access-card"><span className="visitor-initial">{visitor.name.charAt(0)}</span><div className="visitor-access-info"><strong>{visitor.name}</strong><small>آخر ظهور: {new Date(visitor.lastSeenAt).toLocaleString("ar-SA")}</small>{visitor.claimedUserId ? <b className="claimed-access"><ShieldCheck size={13} /> مرتبط بحساب #{visitor.claimedUserId}</b> : <div className="visitor-access-controls"><select value={visitorRole} onChange={(event) => setVisitorRoleDrafts((current) => ({ ...current, [visitor.id]: event.target.value as EditableRole }))}>{editableRoles.map((role) => <option key={role} value={role}>{managedRoleLabels[role]}</option>)}</select><select value={visitorFacility} onChange={(event) => setVisitorFacilityDrafts((current) => ({ ...current, [visitor.id]: event.target.value as FacilityId }))}>{facilities.map((facility) => <option key={facility.id} value={facility.id}>{facility.name}</option>)}</select><button className="apply-role-button" disabled={issueVisitorAccessMutation.isPending} onClick={() => issueVisitorAccessMutation.mutate({ visitorId: visitor.id, role: visitorRole, facilityId: visitorFacility })}><KeyRound size={14} /> إصدار رمز تفعيل</button></div>}{issuedCode && <div className="issued-access-code"><code>{issuedCode}</code><button onClick={() => navigator.clipboard.writeText(issuedCode).then(() => toast.success("تم نسخ الرمز"))}>نسخ</button><small>صالح 48 ساعة ويستخدم مرة واحدة</small></div>}</div></article>; }) : <div className="audit-empty"><Users size={24} /><p>ستظهر الأسماء هنا فور إدخالها في واجهة البداية.</p></div>}</div></section>
      </div>
    );
  };

  const renderPermits = () => (
    <div className="permit-center"><section className="permit-command"><div><span className="permit-command-icon"><Gavel size={25} /></span><div><p className="eyebrow">خدمة المنشآت المعتمدة</p><h2>مركز تصاريح المزادات</h2><p>أنشئ طلبًا رسميًا يناسب نشاط منشأتك، ثم تابع قرار المراجعة من السجل.</p></div></div>{canSubmitRequests && <button className="primary-button" onClick={() => openService("permit")}><FilePlus2 size={17} /> بدء طلب تصريح</button>}</section><section className="section-shell wide-section">
      <div className="toolbar-row">
        <div className="search-box"><Search size={18} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="ابحث برقم الطلب أو اسم المنشأة" /></div>
        {canSubmitRequests && <button className="primary-button" onClick={() => openService("permit")}><Plus size={18} /> طلب تصريح جديد</button>}
      </div>
      {renderPermitsTable()}
      {filteredPermits.length === 0 && <div className="empty-state"><Gavel size={24} /><p>لا توجد طلبات مطابقة للبحث.</p></div>}
    </section></div>
  );

  const renderRent = () => (
    <div className="rent-page-grid">
      <section className="section-shell rent-section">
        <div className="rent-header"><div className="section-heading"><div><p className="eyebrow">سبتمبر 2026</p><h2>جدول الإيجارات الأسبوعي</h2><small className="rent-channel-label">القناة: {selectedFacility.channel}</small></div><span className="monthly-total">إجمالي الشهر <b>{monthlyRentTotal} ر.س</b></span></div>{isSystemOwner && <select className="rent-facility-select" value={selectedFacilityId} onChange={(event) => setSelectedFacilityId(event.target.value as FacilityId)}>{facilities.map((facility) => <option key={facility.id} value={facility.id}>{facility.name}</option>)}</select>}</div>
        <div className="rent-legend"><span><i className="legend-dot paid" /> تم التأكيد</span><span><i className="legend-dot due" /> بانتظار السداد</span><span>حدّث حالة الدفع بعد التحقق من الإيصال.</span></div>
        {renderRentRows(true)}
      </section>
      <aside className="section-shell rent-guidance">
        <span className="guidance-icon"><Sparkles size={21} /></span>
        <p className="eyebrow">تذكير ذكي</p>
        <h2>نظام السجل المبسّط</h2>
        <p>يسهّل عليك السجل الأسبوعي متابعة الدفعات، مع علامة تأكيد واضحة عند اكتمال السداد.</p>
        <div className="guidance-stat"><strong>{pendingRents}</strong><span>دفعات متبقية<br />لشهر سبتمبر</span></div>
        <button className="soft-button full" onClick={() => toast.info("تظهر التنبيهات داخل لوحة التحكم قبل مواعيد الاستحقاق.")}>إعدادات التنبيهات <Settings2 size={16} /></button>
      </aside>
    </div>
  );

  const renderServiceFields = () => {
    if (!selectedService) return null;
    const input = (key: string, label: string, placeholder = "", required = true) => <label key={key}>{label}{required && <em>*</em>}<input value={serviceDraft[key] || ""} onChange={(event) => updateServiceDraft(key, event.target.value)} placeholder={placeholder} /></label>;
    const select = (key: string, label: string, options: string[]) => <label key={key}>{label}<em>*</em><select value={serviceDraft[key] || ""} onChange={(event) => updateServiceDraft(key, event.target.value)}><option value="">اختر من القائمة</option>{options.map((option) => <option key={option} value={option}>{option}</option>)}</select></label>;
    const textarea = (key: string, label: string, placeholder = "") => <label key={key}>{label}<em>*</em><textarea rows={4} value={serviceDraft[key] || ""} onChange={(event) => updateServiceDraft(key, event.target.value)} placeholder={placeholder} /></label>;

    if (selectedService.key === "permit") { const auctionProfile = auctionProfiles[selectedFacility.id]; return <div className="service-form-grid facility-aware-form">
      <div className="facility-form-banner"><Building2 size={19} /><span><small>الطلب مخصص تلقائيًا لنشاط</small><strong>{selectedFacility.name}</strong><b>{selectedFacility.type}</b></span></div>
      <label>اسم المنشأة<input value={selectedFacility.name} readOnly /></label><label>اسم مالك المنشأة<input value={selectedFacility.owner} readOnly /></label>{select("auctionType", "نوع الطلب المناسب للنشاط", auctionProfile.types)}{input("summary", auctionProfile.summaryLabel, auctionProfile.summaryPlaceholder)}{textarea("details", auctionProfile.detailsLabel, auctionProfile.detailsPlaceholder)}{input("estimatedCount", "العدد التقريبي (اختياري)", "اكتب رقمًا أو وصفًا عامًا", false)}{input("entryFees", "رسوم الدخول (اختياري)", "مثال: مجانًا أو 50 ر.س", false)}{input("auctionDate", "تاريخ المزاد ووقته", "مثال: 20 سبتمبر 2026، 8 مساءً")}{select("organizers", "هل تم توفير منظمين للمزاد؟", ["نعم", "لا"])}
      <div className="service-note"><ShieldCheck size={17} /><span>سيتم التواصل مع المديرية العامة للأمن العام عند الحاجة. وفي حال إصدار التصريح، سيصدر الموقع للمزاد في ورقة التصريح.</span></div>
    </div>; }
    if (selectedService.key === "objection") return <div className="service-form-grid">{input("facility", "اسم المنشأة")}{input("owner", "اسم المالك")}{input("violationNumber", "رقم صادر المخالفة")}{textarea("reason", "تسبيب اعتراضك", "اكتب أسباب الاعتراض بالتفصيل")}</div>;
    if (selectedService.key === "closure") return <div className="service-form-grid">{input("facility", "اسم المنشأة")}{input("owner", "اسم مالك المنشأة")}{input("decisionNumber", "رقم القرار الصادر")}{textarea("reason", "تسبيب الطلب", "اكتب أسباب الالتماس وملابساته")}</div>;
    if (selectedService.key === "complaint") return <div className="service-form-grid">{select("facility", "المنشأة", ["شركة الأركان العقارية", "مجموعة العليا للسيارات الجديدة", "القادسية للمركبات المستعملة", "ورشة الامتياز لتعديل المركبات", "ورشة ماكنزي لتعديل المركبات"])}{input("contactName", "اسم شخصيتك للتواصل معك")}{input("phone", "رقم جوالك (داخل التقمص)")}{input("discordId", "آيدي الديسكورد (Discord User ID)", "افتح إعدادات ديسكورد ← الوضع المطور، ثم اضغط بالزر الأيمن على اسمك واختر Copy User ID")}{input("worker", "اسم العامل (إن وجد)", "", false)}{input("video", "رابط مقطع الفيديو", "الصق رابط gofile.io هنا", false)}{textarea("problem", "اشرح المشكلة بالتفصيل", "يرجى وصف المشكلة بكل دقة")}<div className="service-note"><KeyRound size={17} /><span>آيدي الديسكورد رقم فقط (وليس اسم المستخدم)، ويُستخدم للتواصل معك رسميًا بخصوص شكواك.</span></div></div>;
    if (selectedService.key === "compensation") return <div className="service-form-grid">{input("character", "اسم الشخصية")}{input("phone", "رقم الجوال")}{select("compensationType", "نوع التعويض", ["استرداد قيمة المركبة", "تعويض عن ضرر", "تعويض آخر"])}{input("amount", "مبلغ التعويض", "بالريال السعودي")}{textarea("evidence", "الدليل", "يجب وضع اسم مركبتك ولوحتها التي قمت ببيعها عن طريق المعرض")}</div>;
    return <div className="service-form-grid">{input("facility", "اسم المنشأة")}{input("owner", "اسم مالك المنشأة")}{textarea("reason", "تسبيب التأخير", "اكتب سبب طلب المهلة")}{select("requestType", "نوع الطلب", [selectedService.key === "weekly" ? "مهلة سداد أسبوعي" : "مهلة سداد شهري"])}<div className="service-note"><ReceiptText size={17} /><span>اختر نوع الطلب بعناية، وسيظهر في سجل الطلبات بعد الإرسال.</span></div></div>;
  };

  const renderRegulations = () => (
    <section className="regulations-layout">
      <div className="regulation-intro service-intro">
        <div><span className="intro-icon"><Sparkles size={25} /></span><p className="eyebrow">خدمات رقمية للمستثمرين والمواطنين</p><h2>من هنا يمكنك إنجاز طلبك</h2><p>اختر الخدمة المطلوبة، املأ البيانات بدقة، ثم أرسل الطلب للمراجعة.</p></div>
        {isSystemOwner && <button className="primary-button" onClick={() => openRegulationEditor()}><Plus size={18} /> إضافة قانون</button>}
      </div>
      <div className="service-groups">
        {canSubmitRequests && <div className="service-group"><div className="group-heading"><span className="group-icon investor"><Building2 size={17} /></span><div><h3>من هُنا يمكنك <b>(خاص بالمستثمرين)</b></h3><p>خدمات الطلبات والاعتراضات الخاصة بالمنشآت</p></div></div><div className="service-cards">{serviceDefinitions.filter((service) => service.audience === "خاص بالمستثمرين").map((service) => { const Icon = service.icon; return <button className="service-card" key={service.key} onClick={() => openService(service.key)}><span className="service-card-icon"><Icon size={19} /></span><span><strong>{service.title}</strong><small>{service.description}</small></span><ChevronLeft size={16} /></button>; })}</div></div>}
        <div className="service-group citizen-group"><div className="group-heading"><span className="group-icon citizen"><UserRound size={17} /></span><div><h3>من هُنا يمكنك <b>(خاص بالمواطن)</b></h3><p>قنوات البلاغات وطلبات التعويض</p></div></div><div className="service-cards">{serviceDefinitions.filter((service) => service.audience === "خاص بالمواطن").map((service) => { const Icon = service.icon; return <button className="service-card" key={service.key} onClick={() => openService(service.key)}><span className="service-card-icon"><Icon size={19} /></span><span><strong>{service.title}</strong><small>{service.description}</small></span><ChevronLeft size={16} /></button>; })}</div></div>
      </div>
      <div className="law-heading"><div><p className="eyebrow">مرجع متجدد</p><h2>القوانين والضوابط</h2></div><span>تأكد من قراءة اللائحة قبل إرسال الطلب</span></div>
      <div className="regulations-grid">
        {visibleRegulations.map((regulation) => (
          <article className="regulation-card" key={regulation.id}>
            <div className="reg-card-top"><span className="category-chip">{regulation.category}</span>{isSystemOwner ? <button className="table-action" onClick={() => openRegulationEditor(regulation)} aria-label="تعديل اللائحة"><Settings2 size={17} /></button> : <span className="law-version">{regulation.version}</span>}</div>
            <h3>{regulation.title}</h3><p>{regulation.body}</p>
            <footer><span>{regulation.updated}{isSystemOwner && regulation.status !== "published" ? ` · ${regulation.status === "draft" ? "مسودة" : "مؤرشفة"}` : ""}</span><button onClick={() => setSelectedRegulation(regulation)}>عرض التفاصيل <ChevronLeft size={15} /></button></footer>
          </article>
        ))}
      </div>
    </section>
  );

  return (
    <div className="portal" dir="rtl">
      <aside className={`sidebar ${menuOpen ? "sidebar-open" : ""}`}>
        <div className="sidebar-top"><MinistryMark /><button className="mobile-close icon-button" onClick={() => setMenuOpen(false)} aria-label="إغلاق القائمة"><X size={18} /></button></div>
        <div className="facility-switcher"><span className="facility-icon"><Building2 size={18} /></span><span><small>{isVisitor ? "الوضع الحالي" : "القناة الخاصة"}</small><strong>{isVisitor ? "زائر عام" : selectedFacility.name}</strong></span><ChevronLeft size={16} /></div>
        <nav aria-label="التنقل الرئيسي">
          <p className="nav-label">القائمة الرئيسية</p>
          {visibleNavItems.map((item) => { const Icon = item.icon; return <button key={item.id} onClick={() => goTo(item.id)} className={`nav-item ${activePage === item.id ? "active" : ""}`}><Icon size={19} /><span>{isVisitor && item.id === "regulations" ? "قوانين التجارة" : item.label}</span>{item.id === "rent" && pendingRents > 0 && <b className="nav-badge">{pendingRents}</b>}</button>; })}
        </nav>
        <div className="sidebar-help"><span><Bell size={17} /></span><div><strong>هل تحتاج مساعدة؟</strong><p>تواصل مع مركز الأعمال</p></div></div>
        <div className="sidebar-footer"><div className="avatar">{profileName.charAt(0)}</div><div><strong>{profileName}</strong><small>{currentRoleLabel}</small></div><MoreHorizontal size={19} /></div><div className="sidebar-rights"><img src="/brand/roshan.png" alt="شعار روشن" /><span>حقوق روشن © 2026</span></div>
      </aside>
      {menuOpen && <button className="mobile-overlay" onClick={() => setMenuOpen(false)} aria-label="إغلاق القائمة" />}

      <main className="main-content">
        <header className="topbar">
          <button className="mobile-menu icon-button" onClick={() => setMenuOpen(true)} aria-label="فتح القائمة"><Menu size={21} /></button>
          <div className="topbar-mobile-logo"><MinistryMark compact /></div>
          <div className="topbar-spacer" />
          <button className="theme-toggle" onClick={() => toggleTheme?.()} aria-label="تبديل الوضع الليلي">{theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}</button>
          <button className="notification-button" onClick={() => isSystemOwner ? goTo("complaints") : setNotificationsOpen((open) => !open)} aria-label="تنبيهات الشكاوى"><Bell size={20} />{reporterComplaintQuery.data && reporterComplaintQuery.data.status !== "new" && <span />}</button>
          {notificationsOpen && !isSystemOwner && <section className="notification-popover"><div className="notification-head"><div><p className="eyebrow">تنبيهات الشكاوى</p><h3>آخر التحديثات</h3></div><button className="icon-button" onClick={() => setNotificationsOpen(false)} aria-label="إغلاق التنبيهات"><X size={16} /></button></div>{reporterComplaintQuery.data ? <article className={`complaint-notification status-${reporterComplaintQuery.data.status}`}><span>{reporterComplaintQuery.data.status === "new" ? <Clock3 size={18} /> : <CheckCheck size={18} />}</span><div><strong>{reporterComplaintQuery.data.status === "new" ? "الشكوى قيد المراجعة" : reporterComplaintQuery.data.status === "closed" ? "تم إغلاق الشكوى" : "تم قبول الشكوى وفتح الدردشة"}</strong><p>{reporterComplaintQuery.data.reference} · {reporterComplaintQuery.data.facility}</p><button onClick={() => { setNotificationsOpen(false); goTo("complaints"); }}>فتح المتابعة</button></div></article> : <div className="notification-empty"><Bell size={23} /><p>لا توجد تنبيهات شكاوى حاليًا.</p><small>لن تظهر هنا قيم الإيجارات أو إشعارات المنشآت.</small></div>}<div className="notification-policy"><ShieldCheck size={14} /><span>يصل التنبيه بعد قبول الشكوى وتفعيل التواصل الخاص.</span></div></section>}
          <div className="topbar-divider" />
          <button className="profile-button" onClick={() => setProfileDialog(true) }><div className="avatar small">{authUser?.avatarUrl ? <img src={authUser.avatarUrl} alt="" /> : profileName.charAt(0)}</div><span><strong>{authUser?.name || profileName}</strong><small>{currentRoleLabel} · {isVisitor ? "دخول عام" : selectedFacility.name}</small></span><ChevronLeft size={16} /></button>
        </header>
        <div className="page-content">
          <section className="page-hero">
            <div><p className="eyebrow">{pageInfo[activePage].eyebrow}</p><h1>{pageInfo[activePage].title}</h1><p className="page-description">{pageInfo[activePage].description}</p></div>
            <div className="date-chip"><CalendarDays size={17} /><span>الجمعة، 11 سبتمبر 2026</span></div>
          </section>
          {activePage === "dashboard" && (isVisitor ? renderVisitorHome() : renderDashboard())}
          {activePage === "complaints" && renderComplaints()}
          {activePage === "permits" && renderPermits()}
          {activePage === "rent" && renderRent()}
          {activePage === "regulations" && renderRegulations()}
          {activePage === "access" && renderAccessCenter()}
          <div className="site-rights"><img src="/brand/roshan.png" alt="شعار روشن" /><span>حقوق روشن © 2026</span></div>
        </div>
      </main>

      {serviceDialog && selectedService && <Dialog title={selectedService.title} onClose={() => setServiceDialog(null)}><div className="service-dialog-intro"><span className="audience-chip">{selectedService.audience}</span><p>قم بتعبئة البيانات المطلوبة بدقة. الحقول المعلّمة بنجمة مطلوبة.</p></div><div className="form-stack">{renderServiceFields()}<div className="dialog-actions"><button className="soft-button" onClick={() => setServiceDialog(null)}>إلغاء</button><button className="primary-button" disabled={createAuctionMutation.isPending || createComplaintMutation.isPending} onClick={submitService}><CheckCircle2 size={16} /> إرسال الطلب</button></div></div></Dialog>}
      {dialog === "regulation" && <Dialog title={editingRegulationId ? "تعديل اللائحة" : "إضافة لائحة"} onClose={() => setDialog(null)}><div className="form-stack"><label>عنوان اللائحة<input value={regulationForm.title} onChange={(event) => setRegulationForm({ ...regulationForm, title: event.target.value })} placeholder="مثال: ضوابط استخدام المنصة" autoFocus /></label><label>التصنيف<input value={regulationForm.category} onChange={(event) => setRegulationForm({ ...regulationForm, category: event.target.value })} placeholder="مثال: الخدمات الرقمية" /></label><label>ملخص اللائحة<textarea value={regulationForm.body} onChange={(event) => setRegulationForm({ ...regulationForm, body: event.target.value })} placeholder="اكتب النطاق والهدف" rows={3} /></label><label>المواد والضوابط <small>كل مادة في سطر مستقل</small><textarea value={regulationForm.clauses} onChange={(event) => setRegulationForm({ ...regulationForm, clauses: event.target.value })} placeholder={"المادة الأولى...\nالمادة الثانية..."} rows={7} /></label><div className="form-inline"><label>الإصدار<input value={regulationForm.version} onChange={(event) => setRegulationForm({ ...regulationForm, version: event.target.value })} /></label><label>حالة النشر<select value={regulationForm.status} onChange={(event) => setRegulationForm({ ...regulationForm, status: event.target.value as typeof regulationForm.status })}><option value="published">منشورة</option><option value="draft">مسودة</option><option value="archived">مؤرشفة</option></select></label></div><div className="dialog-actions"><button className="soft-button" onClick={() => setDialog(null)}>إلغاء</button><button className="primary-button" disabled={saveRegulationMutation.isPending} onClick={saveRegulation}>حفظ التحديث</button></div></div></Dialog>}
      {selectedAuctionRequest && <Dialog title={`مراجعة طلب ${selectedAuctionRequest.reference}`} onClose={() => setSelectedPermitId(null)}><article className="auction-review"><div className="auction-review-head"><span><Gavel size={23} /></span><div><p>{facilities.find((facility) => facility.id === selectedAuctionRequest.facilityId)?.name}</p><h3>{selectedAuctionRequest.requestType}</h3></div></div><dl><div><dt>وصف المعروض</dt><dd>{selectedAuctionRequest.summary}</dd></div><div><dt>التفاصيل</dt><dd>{selectedAuctionRequest.details}</dd></div><div><dt>الموعد</dt><dd>{selectedAuctionRequest.auctionDate}</dd></div><div><dt>المنظمون</dt><dd>{selectedAuctionRequest.organizers === "yes" ? "تم توفير منظمين" : "لم يتم توفير منظمين"}</dd></div>{selectedAuctionRequest.decisionNote && <div><dt>ملاحظة القرار</dt><dd>{selectedAuctionRequest.decisionNote}</dd></div>}</dl>{isSystemOwner && ["new", "needs_info"].includes(selectedAuctionRequest.status) && <div className="auction-review-actions"><button className="approve-permit" disabled={decideAuctionMutation.isPending} onClick={() => decideAuctionMutation.mutate({ id: selectedAuctionRequest.id, status: "approved", decisionNote: "تمت الموافقة بعد مراجعة البيانات" })}><CheckCircle2 size={15} /> قبول الطلب</button><button className="needs-info-permit" disabled={decideAuctionMutation.isPending} onClick={() => decideAuctionMutation.mutate({ id: selectedAuctionRequest.id, status: "needs_info", decisionNote: "يرجى استكمال بيانات الطلب" })}>طلب استكمال</button><button className="reject-permit" disabled={decideAuctionMutation.isPending} onClick={() => decideAuctionMutation.mutate({ id: selectedAuctionRequest.id, status: "rejected", decisionNote: "تم رفض الطلب بعد المراجعة" })}>رفض الطلب</button></div>}</article></Dialog>}
      {selectedRegulation && <Dialog title="تفاصيل اللائحة" onClose={() => setSelectedRegulation(null)}><article className="official-law-detail"><header><span className="law-seal"><FileText size={24} /></span><div><p>{selectedRegulation.category}</p><h2>{selectedRegulation.title}</h2><small>{selectedRegulation.updated}</small></div></header><div className="law-summary"><strong>النطاق والهدف</strong><p>{selectedRegulation.body}</p></div><div className="law-clauses"><h3>الضوابط الأساسية</h3>{selectedRegulation.clauses.map((clause, index) => <div key={`${selectedRegulation.id}-${index}`}><span>{index + 1}</span><p>{clause}</p></div>)}</div><div className="law-disclaimer"><ShieldCheck size={16} /><span>هذه النسخة مرجعية داخل البوابة. يُعتد بالقرار أو التصريح النهائي الصادر من الجهة المخولة.</span></div></article><div className="dialog-actions"><button className="primary-button" onClick={() => setSelectedRegulation(null)}>تم الاطلاع</button></div></Dialog>}
      {submittedDocument && <Dialog title="تم تقديم الطلب بنجاح" onClose={() => setSubmittedDocument(null)}><div className="official-document"><div className="official-document-head"><MinistryMark /><div className="official-stamp">نسخة إلكترونية<br /><b>معتمدة للاستعراض</b></div></div><div className="official-document-title"><p>وزارة التجارة · بوابة الخدمات</p><h2>{submittedDocument.title}</h2><span>رقم المرجع: <b>{submittedDocument.reference}</b></span></div><div className="official-document-meta"><span>تاريخ التقديم: {submittedDocument.date}</span><span>الحالة: <b>قيد المراجعة</b></span></div><div className="official-fields">{submittedDocument.fields.map((field) => <div key={field.label}><span>{documentFieldLabels[field.label] || field.label}</span><strong>{field.value}</strong></div>)}</div><div className="official-notice"><ShieldCheck size={16} /><span>احتفظ بهذا المستند لمتابعة الطلب. لا يُعد هذا الإشعار موافقة نهائية إلا بعد صدور القرار الرسمي.</span></div><div className="official-document-footer"><span>حقوق روشن © 2026</span><span>بوابة وزارة التجارة</span></div></div><div className="dialog-actions pdf-actions"><button className="soft-button" onClick={() => setSubmittedDocument(null)}>إغلاق</button><button className="primary-button" onClick={downloadSubmittedPdf}>تحميل / حفظ PDF</button></div></Dialog>}
      {profileDialog && <Dialog title="إعدادات الحساب" onClose={() => setProfileDialog(false)}><div className="form-stack"><label>الاسم الظاهر داخل البوابة<input value={profileName} onChange={(event) => setProfileName(event.target.value)} placeholder="اكتب الاسم الظاهر داخل البوابة" disabled={Boolean(authUser?.nameChangedAt)} autoFocus />{authUser?.nameChangedAt ? <small>تم تثبيت الاسم؛ التغيير مسموح مرة واحدة فقط.</small> : <small>يمكن تغيير الاسم مرة واحدة فقط، أما هوية OAuth فلا تتغير.</small>}</label>{authUser && <div className="profile-role-display"><UserRound size={17} /><span><strong>{authUser.name || "حساب OAuth"}</strong><small>المزود: {authUser.loginMethod || "OAuth"} · البريد: {authUser.email || "غير متاح"}</small></span></div>}<label>الرتبة الحالية<div className="profile-role-display"><ShieldCheck size={17} /><span><strong>{isSystemOwner ? "مالك النظام" : roleLabels[effectiveRole]}</strong><small>تُقرأ من الخادم ولا يمكن تعديلها من الملف الشخصي</small></span></div></label><label>قناة المنشأة<div className="profile-role-display"><Building2 size={17} /><span><strong>{isSystemOwner ? "جميع قنوات المنشآت" : authUser ? hasAssignedFacility ? selectedFacility.name : "بانتظار تعيين المالك" : "غير متاحة للزائر العام"}</strong><small>{isSystemOwner ? "يمكنك إدارة تعيين القنوات من مركز الصلاحيات" : "القناة يحددها مالك النظام ولا يمكن للمستخدم تبديلها"}</small></span></div></label><div className="role-note"><Users size={17} /><span>{isSystemOwner ? "لتعديل رتبة مستخدم أو قناته انتقل إلى مركز الصلاحيات من القائمة الرئيسية." : "لا يمكنك رفع رتبتك أو تغيير قناتك بنفسك. يحدد مالك النظام صلاحيات الحساب."}</span></div>{isSystemOwner && <button className="access-shortcut" onClick={() => { setProfileDialog(false); goTo("access"); }}><KeyRound size={16} /> فتح مركز الصلاحيات</button>}{authUser && !isSystemOwner && <div className="claim-access-box"><div><KeyRound size={17} /><span><strong>لديك رمز تفعيل من المالك؟</strong><small>الرمز يمنح الرتبة والمنشأة التي حددها المالك فقط.</small></span></div><div><input value={claimCode} onChange={(event) => setClaimCode(event.target.value)} placeholder="أدخل رمز التفعيل المؤقت" maxLength={16} /><button className="soft-button" disabled={claimVisitorAccessMutation.isPending || claimCode.length !== 16} onClick={() => claimVisitorAccessMutation.mutate({ claimCode })}>تفعيل</button></div></div>}<div className="dialog-actions"><button className="soft-button" onClick={() => setProfileDialog(false)}>إلغاء</button><button className="primary-button" disabled={updateNameMutation.isPending || Boolean(authUser?.nameChangedAt)} onClick={saveProfile}><Check size={16} /> {authUser?.nameChangedAt ? "الاسم مثبت" : "حفظ الاسم"}</button></div></div></Dialog>}
      <button className={`ai-chat-launcher ${aiChatOpen ? "is-hidden" : ""}`} onClick={() => setAiChatOpen(true)} aria-label="اسأل مساعد البوابة"><Sparkles size={20} /><span>اسأل عن القوانين</span></button>
      {aiChatOpen && <div className="ai-chat-panel" role="dialog" aria-modal="true" aria-label="مساعد البوابة الذكي">
        <div className="ai-chat-head"><span className="ai-chat-avatar"><Sparkles size={18} /></span><div><strong>مساعد البوابة</strong><small>يجيب استنادًا إلى القوانين المنشورة فقط</small></div><button className="icon-button" onClick={() => setAiChatOpen(false)} aria-label="إغلاق المساعد"><X size={16} /></button></div>
        <div className="ai-chat-body">
          {aiChatHistory.length === 0 && <div className="ai-chat-empty"><Sparkles size={22} /><p>اسأل أي سؤال عن قوانين وضوابط وزارة التجارة داخل البوابة، وسيرد المساعد بناءً على اللوائح المنشورة فعليًا.</p></div>}
          {aiChatHistory.map((message, index) => <div key={index} className={`ai-chat-bubble ${message.role}`}>{message.text}</div>)}
          {aiChatMutation.isPending && <div className="ai-chat-bubble assistant ai-chat-typing"><span /><span /><span /></div>}
        </div>
        <div className="ai-chat-compose"><input value={aiChatInput} onChange={(event) => setAiChatInput(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") sendAiChatMessage(); }} placeholder="اكتب سؤالك عن القوانين..." maxLength={600} /><button className="icon-button ai-chat-send" disabled={!aiChatInput.trim() || aiChatMutation.isPending} onClick={sendAiChatMessage} aria-label="إرسال"><Send size={16} /></button></div>
      </div>}
      {showWelcome && <div className="dialog-backdrop welcome-backdrop"><section className="welcome-card" role="dialog" aria-modal="true" aria-label="تنبيه الاستخدام الأول"><div className="welcome-ministry-brand"><img src="/manus-storage/ministry-commerce-entry_294b87e1.png" alt="شعار وزارة التجارة السعودية" /><strong>وزارة التجارة</strong></div><p className="eyebrow">البوابة الرسمية للخدمات</p><h2>{authUser ? `مرحبًا ${authUser.name || "بك"}` : "مرحبًا بك في خدمات المنشآت"}</h2><p className="welcome-lead">{authUser ? `تم تسجيل الدخول عبر ${authUser.loginMethod || "مزود الهوية"}.` : "قبل البدء، يرجى قراءة التنبيه التالي بعناية:"}</p><label className="welcome-name">اسمك داخل البوابة<input value={profileName === "زائر" ? "" : profileName} onChange={(event) => setProfileName(event.target.value)} placeholder="اكتب اسمك" autoFocus /></label><div className="welcome-rules"><div><Check size={15} /><span>استخدم الخدمة المناسبة لطبيعة طلبك، وأدخل البيانات الصحيحة والكاملة.</span></div><div><Check size={15} /><span>عدم التهاون أو الاستهتار في الطلبات؛ الطلبات غير الجادة أو المضللة قد تخضع للإجراء النظامي.</span></div><div><Check size={15} /><span>اطلع على القوانين والضوابط قبل الإرسال، وتحمّل مسؤولية صحة المعلومات المقدمة.</span></div></div><div className="welcome-footer"><span className="roshan-credit"><img src="/brand/roshan.png" alt="شعار روشن" /> <strong>حقوق روشن © 2026</strong></span></div><button className="primary-button full" onClick={() => { if (!profileName.trim() || profileName === "زائر") { toast.error("اكتب اسمك أولًا"); return; } registerVisitorMutation.mutate({ name: profileName.trim(), visitorKey }); localStorage.setItem("tijara-welcome-seen", "1"); setShowWelcome(false); }}>أوافق وأبدأ التصفح</button></section></div>}
    </div>
  );
}
