CREATE TABLE `complaintMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`complaintId` int NOT NULL,
	`senderRole` enum('reporter','owner') NOT NULL,
	`body` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `complaintMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `complaints` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reference` varchar(32) NOT NULL,
	`facility` varchar(180) NOT NULL,
	`reporterName` varchar(120) NOT NULL,
	`phone` varchar(40) NOT NULL,
	`subject` varchar(180) NOT NULL DEFAULT 'بلاغ على منشأة',
	`status` enum('new','open','closed') NOT NULL DEFAULT 'new',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `complaints_id` PRIMARY KEY(`id`),
	CONSTRAINT `complaints_reference_unique` UNIQUE(`reference`)
);
