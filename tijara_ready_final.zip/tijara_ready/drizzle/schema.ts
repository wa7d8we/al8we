import { index, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  avatarUrl: varchar("avatarUrl", { length: 500 }),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  nameChangedAt: timestamp("nameChangedAt"),
  role: mysqlEnum("role", ["visitor", "owner", "manager", "staff", "user", "admin"]).default("user").notNull(),
  facilityId: varchar("facilityId", { length: 16 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const visitorRegistrations = mysqlTable("visitorRegistrations", {
  id: int("id").autoincrement().primaryKey(),
  visitorKey: varchar("visitorKey", { length: 64 }).unique(),
  name: varchar("name", { length: 120 }).notNull(),
  pendingRole: mysqlEnum("pendingRole", ["visitor", "owner", "manager", "staff"]),
  facilityId: varchar("facilityId", { length: 16 }),
  claimCodeHash: varchar("claimCodeHash", { length: 128 }),
  claimCodeExpiresAt: timestamp("claimCodeExpiresAt"),
  claimedUserId: int("claimedUserId").unique().references(() => users.id),
  approvedByUserId: int("approvedByUserId").references(() => users.id),
  approvedAt: timestamp("approvedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  lastSeenAt: timestamp("lastSeenAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("visitor_last_seen_idx").on(table.lastSeenAt), index("visitor_pending_access_idx").on(table.pendingRole, table.approvedAt)]);

export type VisitorRegistration = typeof visitorRegistrations.$inferSelect;
export type InsertVisitorRegistration = typeof visitorRegistrations.$inferInsert;

export const complaints = mysqlTable("complaints", {
  id: int("id").autoincrement().primaryKey(),
  reference: varchar("reference", { length: 32 }).notNull().unique(),
  facility: varchar("facility", { length: 180 }).notNull(),
  reporterName: varchar("reporterName", { length: 120 }).notNull(),
  phone: varchar("phone", { length: 40 }).notNull(),
  workerName: varchar("workerName", { length: 120 }),
  discordUserId: varchar("discordUserId", { length: 32 }),
  evidenceUrl: varchar("evidenceUrl", { length: 500 }),
  trackingTokenHash: varchar("trackingTokenHash", { length: 128 }),
  subject: varchar("subject", { length: 180 }).default("بلاغ على منشأة").notNull(),
  status: mysqlEnum("status", ["new", "accepted", "open", "closed"]).default("new").notNull(),
  acceptedAt: timestamp("acceptedAt"),
  lastMessageAt: timestamp("lastMessageAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("complaint_status_activity_idx").on(table.status, table.lastMessageAt)]);

export const complaintMessages = mysqlTable("complaintMessages", {
  id: int("id").autoincrement().primaryKey(),
  complaintId: int("complaintId").notNull().references(() => complaints.id, { onDelete: "cascade" }),
  senderRole: mysqlEnum("senderRole", ["reporter", "owner"]).notNull(),
  body: text("body").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("complaint_message_thread_idx").on(table.complaintId, table.createdAt)]);

export type Complaint = typeof complaints.$inferSelect;
export type ComplaintMessage = typeof complaintMessages.$inferSelect;

export const roleAuditLogs = mysqlTable("roleAuditLogs", {
  id: int("id").autoincrement().primaryKey(),
  actorUserId: int("actorUserId").notNull(),
  actorName: varchar("actorName", { length: 160 }).notNull(),
  targetUserId: int("targetUserId").notNull(),
  targetName: varchar("targetName", { length: 160 }).notNull(),
  previousRole: mysqlEnum("previousRole", ["visitor", "owner", "manager", "staff", "user", "admin"]).notNull(),
  newRole: mysqlEnum("newRole", ["visitor", "owner", "manager", "staff", "user", "admin"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type RoleAuditLog = typeof roleAuditLogs.$inferSelect;

export const auctionRequests = mysqlTable("auctionRequests", {
  id: int("id").autoincrement().primaryKey(),
  reference: varchar("reference", { length: 40 }).notNull().unique(),
  facilityId: varchar("facilityId", { length: 16 }).notNull(),
  requesterUserId: int("requesterUserId").notNull().references(() => users.id),
  requestType: varchar("requestType", { length: 100 }).notNull(),
  summary: varchar("summary", { length: 240 }).notNull(),
  details: text("details").notNull(),
  auctionDate: varchar("auctionDate", { length: 120 }).notNull(),
  organizers: mysqlEnum("organizers", ["yes", "no"]).notNull(),
  status: mysqlEnum("status", ["new", "approved", "rejected", "needs_info"]).default("new").notNull(),
  decisionNote: text("decisionNote"),
  decidedByUserId: int("decidedByUserId").references(() => users.id),
  decidedAt: timestamp("decidedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("auction_facility_status_idx").on(table.facilityId, table.status, table.createdAt)]);

export type AuctionRequest = typeof auctionRequests.$inferSelect;

export const rentPayments = mysqlTable("rentPayments", {
  id: int("id").autoincrement().primaryKey(),
  facilityId: varchar("facilityId", { length: 16 }).notNull(),
  weekNumber: int("weekNumber").notNull(),
  unitName: varchar("unitName", { length: 180 }).notNull(),
  amount: int("amount").notNull(),
  dueLabel: varchar("dueLabel", { length: 120 }).notNull(),
  note: varchar("note", { length: 240 }).notNull(),
  paidAt: timestamp("paidAt"),
  confirmedByUserId: int("confirmedByUserId").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("rent_facility_week_unique").on(table.facilityId, table.weekNumber), index("rent_facility_due_idx").on(table.facilityId, table.paidAt)]);

export type RentPayment = typeof rentPayments.$inferSelect;

export const regulations = mysqlTable("regulations", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 40 }).notNull().unique(),
  title: varchar("title", { length: 240 }).notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  summary: text("summary").notNull(),
  clausesJson: text("clausesJson").notNull(),
  version: varchar("version", { length: 40 }).notNull(),
  status: mysqlEnum("status", ["draft", "published", "archived"]).default("published").notNull(),
  effectiveAt: timestamp("effectiveAt").defaultNow().notNull(),
  createdByUserId: int("createdByUserId").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("regulation_publication_idx").on(table.status, table.effectiveAt)]);

export type Regulation = typeof regulations.$inferSelect;

/**
 * One row per successful sign-in. Lets the system owner see exactly who
 * entered the portal, by name, and when — separate from `users.lastSignedIn`
 * which only keeps the most recent value.
 */
export const loginEvents = mysqlTable("loginEvents", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  name: varchar("name", { length: 160 }),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  ipAddress: varchar("ipAddress", { length: 64 }),
  userAgent: varchar("userAgent", { length: 300 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("login_event_user_idx").on(table.userId, table.createdAt), index("login_event_created_idx").on(table.createdAt)]);

export type LoginEvent = typeof loginEvents.$inferSelect;

/**
 * Stores the visitor AI assistant conversation turns so the owner can audit
 * what the assistant told visitors about trade regulations.
 */
export const aiChatMessages = mysqlTable("aiChatMessages", {
  id: int("id").autoincrement().primaryKey(),
  visitorKey: varchar("visitorKey", { length: 64 }).notNull(),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("ai_chat_visitor_idx").on(table.visitorKey, table.createdAt)]);

export type AiChatMessage = typeof aiChatMessages.$inferSelect;
