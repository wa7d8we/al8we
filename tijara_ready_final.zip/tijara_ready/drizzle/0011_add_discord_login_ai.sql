ALTER TABLE `complaints` ADD `discordUserId` varchar(32);--> statement-breakpoint
CREATE TABLE `loginEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(160),
	`email` varchar(320),
	`loginMethod` varchar(64),
	`ipAddress` varchar(64),
	`userAgent` varchar(300),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `loginEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `aiChatMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`visitorKey` varchar(64) NOT NULL,
	`question` text NOT NULL,
	`answer` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `aiChatMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `loginEvents` ADD CONSTRAINT `loginEvents_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
CREATE INDEX `login_event_user_idx` ON `loginEvents` (`userId`,`createdAt`);
--> statement-breakpoint
CREATE INDEX `login_event_created_idx` ON `loginEvents` (`createdAt`);
--> statement-breakpoint
CREATE INDEX `ai_chat_visitor_idx` ON `aiChatMessages` (`visitorKey`,`createdAt`);
