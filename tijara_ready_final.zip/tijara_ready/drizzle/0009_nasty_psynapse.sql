CREATE TABLE `rentPayments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`facilityId` varchar(16) NOT NULL,
	`weekNumber` int NOT NULL,
	`unitName` varchar(180) NOT NULL,
	`amount` int NOT NULL,
	`dueLabel` varchar(120) NOT NULL,
	`note` varchar(240) NOT NULL,
	`paidAt` timestamp,
	`confirmedByUserId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `rentPayments_id` PRIMARY KEY(`id`),
	CONSTRAINT `rent_facility_week_unique` UNIQUE(`facilityId`,`weekNumber`)
);
--> statement-breakpoint
ALTER TABLE `rentPayments` ADD CONSTRAINT `rentPayments_confirmedByUserId_users_id_fk` FOREIGN KEY (`confirmedByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `rent_facility_due_idx` ON `rentPayments` (`facilityId`,`paidAt`);