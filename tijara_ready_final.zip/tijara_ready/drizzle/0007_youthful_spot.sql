ALTER TABLE `users` MODIFY COLUMN `role` enum('visitor','owner','manager','staff','user','admin') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `facilityId` varchar(16);