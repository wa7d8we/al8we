CREATE TABLE `auctionRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reference` varchar(40) NOT NULL,
	`facilityId` varchar(16) NOT NULL,
	`requesterUserId` int NOT NULL,
	`requestType` varchar(100) NOT NULL,
	`summary` varchar(240) NOT NULL,
	`details` text NOT NULL,
	`auctionDate` varchar(120) NOT NULL,
	`organizers` enum('yes','no') NOT NULL,
	`status` enum('new','approved','rejected','needs_info') NOT NULL DEFAULT 'new',
	`decisionNote` text,
	`decidedByUserId` int,
	`decidedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `auctionRequests_id` PRIMARY KEY(`id`),
	CONSTRAINT `auctionRequests_reference_unique` UNIQUE(`reference`)
);
--> statement-breakpoint
CREATE TABLE `regulations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(40) NOT NULL,
	`title` varchar(240) NOT NULL,
	`category` varchar(100) NOT NULL,
	`summary` text NOT NULL,
	`clausesJson` text NOT NULL,
	`version` varchar(40) NOT NULL,
	`status` enum('draft','published','archived') NOT NULL DEFAULT 'published',
	`effectiveAt` timestamp NOT NULL DEFAULT (now()),
	`createdByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `regulations_id` PRIMARY KEY(`id`),
	CONSTRAINT `regulations_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
ALTER TABLE `visitorRegistrations` ADD `pendingRole` enum('visitor','owner','manager','staff');--> statement-breakpoint
ALTER TABLE `visitorRegistrations` ADD `facilityId` varchar(16);--> statement-breakpoint
ALTER TABLE `visitorRegistrations` ADD `claimCodeHash` varchar(128);--> statement-breakpoint
ALTER TABLE `visitorRegistrations` ADD `claimCodeExpiresAt` timestamp;--> statement-breakpoint
ALTER TABLE `visitorRegistrations` ADD `claimedUserId` int;--> statement-breakpoint
ALTER TABLE `visitorRegistrations` ADD `approvedByUserId` int;--> statement-breakpoint
ALTER TABLE `visitorRegistrations` ADD `approvedAt` timestamp;--> statement-breakpoint
ALTER TABLE `visitorRegistrations` ADD CONSTRAINT `visitorRegistrations_claimedUserId_unique` UNIQUE(`claimedUserId`);--> statement-breakpoint
ALTER TABLE `auctionRequests` ADD CONSTRAINT `auctionRequests_requesterUserId_users_id_fk` FOREIGN KEY (`requesterUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `auctionRequests` ADD CONSTRAINT `auctionRequests_decidedByUserId_users_id_fk` FOREIGN KEY (`decidedByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `regulations` ADD CONSTRAINT `regulations_createdByUserId_users_id_fk` FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `auction_facility_status_idx` ON `auctionRequests` (`facilityId`,`status`,`createdAt`);--> statement-breakpoint
CREATE INDEX `regulation_publication_idx` ON `regulations` (`status`,`effectiveAt`);--> statement-breakpoint
ALTER TABLE `complaintMessages` ADD CONSTRAINT `complaintMessages_complaintId_complaints_id_fk` FOREIGN KEY (`complaintId`) REFERENCES `complaints`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `visitorRegistrations` ADD CONSTRAINT `visitorRegistrations_claimedUserId_users_id_fk` FOREIGN KEY (`claimedUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `visitorRegistrations` ADD CONSTRAINT `visitorRegistrations_approvedByUserId_users_id_fk` FOREIGN KEY (`approvedByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `complaint_message_thread_idx` ON `complaintMessages` (`complaintId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `complaint_status_activity_idx` ON `complaints` (`status`,`lastMessageAt`);--> statement-breakpoint
CREATE INDEX `visitor_last_seen_idx` ON `visitorRegistrations` (`lastSeenAt`);--> statement-breakpoint
CREATE INDEX `visitor_pending_access_idx` ON `visitorRegistrations` (`pendingRole`,`approvedAt`);