CREATE TABLE `roleAuditLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actorUserId` int NOT NULL,
	`actorName` varchar(160) NOT NULL,
	`targetUserId` int NOT NULL,
	`targetName` varchar(160) NOT NULL,
	`previousRole` enum('visitor','owner','manager','staff','user','admin') NOT NULL,
	`newRole` enum('visitor','owner','manager','staff','user','admin') NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `roleAuditLogs_id` PRIMARY KEY(`id`)
);
