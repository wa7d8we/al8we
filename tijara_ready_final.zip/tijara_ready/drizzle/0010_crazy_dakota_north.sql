ALTER TABLE `complaints` ADD `workerName` varchar(120);--> statement-breakpoint
ALTER TABLE `complaints` ADD `evidenceUrl` varchar(500);