ALTER TABLE `complaints` MODIFY COLUMN `status` enum('new','accepted','open','closed') NOT NULL DEFAULT 'new';--> statement-breakpoint
ALTER TABLE `complaints` ADD `trackingTokenHash` varchar(128);--> statement-breakpoint
ALTER TABLE `complaints` ADD `acceptedAt` timestamp;--> statement-breakpoint
ALTER TABLE `complaints` ADD `lastMessageAt` timestamp DEFAULT (now()) NOT NULL;